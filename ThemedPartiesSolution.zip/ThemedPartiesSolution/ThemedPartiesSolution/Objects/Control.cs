﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution
{
    class Control
    {
        public static int SelectedSearchType;
        public static int DatabaseConnnected = 0; 
    }
}
