﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution.Objects
{
    public class Costume
    {
        public int CostumeID;
        public string Size;
        public string Role;
        public int SupplierID;
    }
}
