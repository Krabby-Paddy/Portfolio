﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution.Objects
{
    public class Staff
    {
        private int staffID;
        private String title;
        private String firstName;
        private String lastName;
        private String contactNo;
        private String address;
        private String town;
        private String postCode;
        private String email;
        private DateTime dob;

        public Staff() { }

        public Staff(int staffID, String title, String firstName, String lastName, String contactNo, String address, String town, String postCode, String email, DateTime dob)
        { this.staffID = staffID; this.title = title; this.firstName = firstName; this.lastName = lastName; this.contactNo = contactNo; this.address = address; this.town = town; this.postCode = postCode; this.email = email; this.dob = dob; }

    public int StaffID { get { return staffID; } set { staffID = value; } } 
    public String Title { get { return title; } set { title = value; } }
    public String FirstName { get { return firstName; } set { firstName = value; } }
    public String LastName { get { return lastName; } set { lastName = value; } }
    public String ContactNo { get { return contactNo; } set { contactNo = value; } }
    public String Address { get { return address; } set { address = value; } }
    public String Town { get { return town; } set { town = value; } }
    public String PostCode { get { return postCode; } set { postCode = value; } }
    public String Email { get { return email; } set { email = value; } }
    public DateTime DOB { get { return dob; } set { dob = value; } }
    }
}
