﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution.Objects
{
    public static class Errors
    {
        public static bool ErrorMessagesFlag = false;
        public static List<string> ErrorMessages = new List<string>();
        public static string DialogResultText;
    }
}