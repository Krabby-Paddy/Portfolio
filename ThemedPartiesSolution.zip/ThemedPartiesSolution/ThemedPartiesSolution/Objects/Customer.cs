﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.Objects
{
    public class Customer
    {
        private int customerID;
        private String title;
        private String firstName;
        private String lastName;
        private String contactNo;
        private String address;
        private String town;
        private String postCode;
        private String email;
        private DateTime dob;
        private string size;

        public Customer() { }

        public Customer(int customerID, String title, String firstName, String lastName, String contactNo, String address, String town, String postCode, String email, DateTime dob, String size)
        { this.customerID = customerID; this.title = title; this.firstName = firstName; this.lastName = lastName; this.contactNo = contactNo; this.address = address; this.town = town; this.postCode = postCode; this.email = email; this.dob = dob; this.size = size; }

        public int CustomerID { get { return customerID; } set { customerID = value; } }
        public String Title
        {
            get { return title; }
            set
            {
                string titleTemp = value;
                if (titleTemp != "Mr" && titleTemp != "Mrs" && titleTemp != "Ms" && titleTemp != "Miss" && titleTemp != "Dr.")
                {
                    Objects.Errors.ErrorMessages.Add("An invalid title has been entered");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
                else
                {
                    title = value;
                }
            }
        }

        public String FirstName
        {
            get { return firstName; }
            set
            {
                string firstnameTemp = value;
                if (firstnameTemp.Length > 50 || string.IsNullOrWhiteSpace(firstnameTemp))
                {
                    Objects.Errors.ErrorMessages.Add("An invalid first name has been entered or the textbox has been left blank");
                    Objects.Errors.ErrorMessagesFlag = true;
                }

                else
                {
                    firstName = value;
                }
            }
        }

        public String LastName
        {
            get { return lastName; }
            set
            {
                string lastNameTemp = value;
                if (lastNameTemp.Length > 50 || string.IsNullOrWhiteSpace(lastNameTemp))
                {
                    {
                        Objects.Errors.ErrorMessages.Add("An invalid last name has been entered or the textbox has been left blank");
                        Objects.Errors.ErrorMessagesFlag = true;
                    }
                }
                else
                {
                    lastName = value;
                }
            }
        }


        public String ContactNo
        {
            get { return contactNo; }
            set
            {
                string contactNoTemp = value;
                bool flag = true;
                if (contactNoTemp.Length != 11)
                {
                    flag = false;
                    Objects.Errors.ErrorMessages.Add("An invalid contact number has been entered, the number must have 11 digits");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
                for (int i = 0; i < contactNoTemp.Length; i++)
                {
                    if (!Char.IsDigit(contactNoTemp[i]))
                    {
                        flag = false;
                        Objects.Errors.ErrorMessages.Add("An invalid contact number has been entered, the number must not contain any letters or symbols");
                        Objects.Errors.ErrorMessagesFlag = true;
                        break;
                    }
                }
                if (flag == true)
                {
                    contactNo = value;
                }
            }
        }


        public String Address
        {
            get { return address; }
            set
            {
                string addressTemp = value;
                if (addressTemp.Length > 50 || !string.IsNullOrWhiteSpace(addressTemp))
                {
                    address = value;
                }
                else
                {
                    Objects.Errors.ErrorMessages.Add("An invalid address has been entered or the textbox has been left blank");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
            }
        }

        public String Town
        {
            get { return town; }
            set
            {
                string townTemp = value;
                if (townTemp.Length > 20 || !string.IsNullOrWhiteSpace(townTemp))
                {
                    town = value;
                }
                else
                {
                    Objects.Errors.ErrorMessages.Add("An invalid Town has been entered or the textbox has been left blank");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
            }
        }

        public String PostCode
        {
            get { return postCode; }
            set
            {
                string postcodeTemp = value;
                if (postcodeTemp.Length != 7)
                {
                    Objects.Errors.ErrorMessages.Add("An invalid postcode has been entered, the code must contain 7 characters");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
                else
                {
                    if (postcodeTemp[0] != 'b' || postcodeTemp[1] != 't')
                    {
                        Objects.Errors.ErrorMessages.Add("An invalid postcode has been entered, a Belfast postcode starting with BT must be entered");
                        Objects.Errors.ErrorMessagesFlag = true;
                    }
                    else
                    {
                        postCode = value;
                    }
                }
            }
        }

        public String Email
        {
            get { return email; }
            set
            {
                string emailTemp = value;
                string errorchars = "!#$%&'*+/=?^`{|}~(),:;<>[ ]/";
                char invalidchar = '"';
                bool flag = true;
                if (string.IsNullOrWhiteSpace(emailTemp)) 
                { 
                    flag = false;
                    Objects.Errors.ErrorMessages.Add("An invalid E-mail address has been entered or the textbox has been left blank");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
                for (int i = 0; i > emailTemp.Length; i++)
                {
                    for (int x = 0; x > errorchars.Length; x++)
                    {
                        if (emailTemp[i] == errorchars[x] || emailTemp[i] == invalidchar)
                        {
                            flag = false;
                            Objects.Errors.ErrorMessages.Add("An invalid E-mail address has been entered or the textbox has been left blank");
                            Objects.Errors.ErrorMessagesFlag = true;
                        }
                    }
                }
                for (int y = 0; y > emailTemp.Length; y++)
                {
                    if (flag = true && emailTemp[y] == '@' && emailTemp.Length > 5)
                    {
                        for (int r = 0; r > emailTemp.Length; r++)
                        {
                            if (emailTemp[r] == '.')
                            {
                                flag = false;

                            }

                        }
                    }
                    else
                            {
                                Objects.Errors.ErrorMessages.Add("An invalid E-mail address has been entered or the textbox has been left blank");
                                Objects.Errors.ErrorMessagesFlag = true;
                            }  
                }
                if (flag == true) { email = value; }
            }
        }


        public DateTime DOB
        {
            get { return dob; }
            set
            {
                DateTime dobTemp = value;

                if (dobTemp <= DateTime.Now.AddYears(-18))
                {
                    dob = value;
                }

                else if (dobTemp >= DateTime.Now.AddYears(-18))
                {
                    Objects.Errors.ErrorMessages.Add("An invalid date of birth has been entered or the textbox has been left blank,"); 
                    Objects.Errors.ErrorMessages.Add("customers must be atleast 18 years old");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
            }
        }

        public String Size
        {
            get { return size; }
            set
            {
                string sizetemp = value;
                if (sizetemp != "Small" && sizetemp != "Medium" && sizetemp != "Large" && sizetemp != "X-Large")
                {
                    Objects.Errors.ErrorMessages.Add("An invalid size has been entered");
                    Objects.Errors.ErrorMessagesFlag = true;
                }
                else
                {
                    size = value;
                }
            }
        }

    }
}