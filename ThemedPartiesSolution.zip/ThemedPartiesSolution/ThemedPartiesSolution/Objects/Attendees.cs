﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution.Objects
{
    public class Attendees
    {
        private int bookingID, customerID, attendeesID, costumeID;

        public int CustomerID { get { return customerID; } set { customerID = value; } }
        public int BookingID { get { return bookingID; } set { bookingID = value; } }
        public int AttendeesID { get { return attendeesID; } set { attendeesID = value; } }
        public int CostumeID { get { return costumeID; } set { costumeID = value; } }
    }
}
