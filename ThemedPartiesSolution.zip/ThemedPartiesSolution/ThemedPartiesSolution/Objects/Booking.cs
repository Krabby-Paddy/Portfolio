﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThemedPartiesSolution.Objects
{
    public class Booking
    {
        private int bookingID, customerID;
        private DateTime dateOfBooking;
        private DateTime dateAndTimeOfEvent;
        private String theme;
        private int timeOfEvent;

        public Booking(){}

        public Booking(int bookingID, DateTime dateofBooking, DateTime dateAndTimeOfEvent, String theme, int CustomerID, int timeOfEvent)
        {
            this.bookingID          = bookingID;
            this.dateOfBooking      = dateofBooking;
            this.dateAndTimeOfEvent = dateAndTimeOfEvent;
            this.theme              = theme;
            this.CustomerID         = CustomerID;
            this.timeOfEvent        = timeOfEvent;
        } 
        public int BookingID { get { return bookingID;} set { bookingID = value; } }
        public int CustomerID { get { return customerID; } set { customerID = value; } }
        public DateTime DateOfBooking { get { return dateOfBooking; } set { dateOfBooking = value; } }
        public int TimeOfEvent { get { return timeOfEvent; } set { timeOfEvent = value; } }
        public DateTime DateAndTimeOfEvent { get { return dateAndTimeOfEvent; } set {
            DateTime TempDATOE = value;
            if (TempDATOE.Date >= DateTime.Today)
            {
                dateAndTimeOfEvent = value;
            }
            else
            {
                Objects.Errors.ErrorMessages.Add("A valid date of event must be entered.");
                Objects.Errors.ErrorMessagesFlag = true;
            }
             } }
        public string Theme                { get { return theme;              } set {
            string TempTheme = value;
            if (TempTheme != "MurderM" && TempTheme != "Bday")
            {
                Objects.Errors.ErrorMessages.Add("A valid theme must be selected.");
                Objects.Errors.ErrorMessagesFlag = true;
            }
            else
            {
                theme = value;
            }
            ; } }
    }
}