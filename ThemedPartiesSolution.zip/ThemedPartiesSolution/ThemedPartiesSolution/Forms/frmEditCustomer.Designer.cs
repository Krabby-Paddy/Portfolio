﻿namespace ThemedPartiesSolution
{
    partial class frmEditCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditCustomer));
            this.lblAddCusFormTitle = new System.Windows.Forms.Label();
            this.GboxSearchBy = new System.Windows.Forms.GroupBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.lBoxListResults = new System.Windows.Forms.ListBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblIDlabel = new System.Windows.Forms.Label();
            this.lblCustomerlabel = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.GboxEditDetails = new System.Windows.Forms.GroupBox();
            this.cboxSize = new System.Windows.Forms.ComboBox();
            this.lblSize = new System.Windows.Forms.Label();
            this.DTPickerDOB = new System.Windows.Forms.DateTimePicker();
            this.btnSaveChanges = new System.Windows.Forms.Button();
            this.cboxtitle = new System.Windows.Forms.ComboBox();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.lblContactNumber = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.txtTown = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtLastN = new System.Windows.Forms.TextBox();
            this.txtFirstN = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblTown = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblPostCode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnRtrnToMM = new System.Windows.Forms.Button();
            this.GboxSearchBy.SuspendLayout();
            this.GboxEditDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAddCusFormTitle
            // 
            this.lblAddCusFormTitle.AutoSize = true;
            this.lblAddCusFormTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblAddCusFormTitle.Font = new System.Drawing.Font("Tahoma", 20F);
            this.lblAddCusFormTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddCusFormTitle.Location = new System.Drawing.Point(12, 22);
            this.lblAddCusFormTitle.Name = "lblAddCusFormTitle";
            this.lblAddCusFormTitle.Size = new System.Drawing.Size(182, 33);
            this.lblAddCusFormTitle.TabIndex = 24;
            this.lblAddCusFormTitle.Text = "Edit Customer";
            this.lblAddCusFormTitle.Click += new System.EventHandler(this.lblAddCusFormTitle_Click);
            // 
            // GboxSearchBy
            // 
            this.GboxSearchBy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GboxSearchBy.BackgroundImage")));
            this.GboxSearchBy.Controls.Add(this.btnSelect);
            this.GboxSearchBy.Controls.Add(this.lBoxListResults);
            this.GboxSearchBy.Controls.Add(this.btnSearch);
            this.GboxSearchBy.Controls.Add(this.lblIDlabel);
            this.GboxSearchBy.Controls.Add(this.lblCustomerlabel);
            this.GboxSearchBy.Controls.Add(this.txtID);
            this.GboxSearchBy.Controls.Add(this.txtSurname);
            this.GboxSearchBy.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.GboxSearchBy.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.GboxSearchBy.Location = new System.Drawing.Point(12, 72);
            this.GboxSearchBy.Name = "GboxSearchBy";
            this.GboxSearchBy.Size = new System.Drawing.Size(1066, 202);
            this.GboxSearchBy.TabIndex = 25;
            this.GboxSearchBy.TabStop = false;
            this.GboxSearchBy.Text = "Search for a Customer";
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.DeepPink;
            this.btnSelect.Enabled = false;
            this.btnSelect.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSelect.Location = new System.Drawing.Point(254, 127);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(192, 30);
            this.btnSelect.TabIndex = 7;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // lBoxListResults
            // 
            this.lBoxListResults.BackColor = System.Drawing.Color.Thistle;
            this.lBoxListResults.Font = new System.Drawing.Font("Tahoma", 14F);
            this.lBoxListResults.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lBoxListResults.FormattingEnabled = true;
            this.lBoxListResults.ItemHeight = 23;
            this.lBoxListResults.Location = new System.Drawing.Point(512, 48);
            this.lBoxListResults.Name = "lBoxListResults";
            this.lBoxListResults.Size = new System.Drawing.Size(532, 142);
            this.lBoxListResults.TabIndex = 6;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.DeepPink;
            this.btnSearch.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSearch.Location = new System.Drawing.Point(27, 127);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(192, 30);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblIDlabel
            // 
            this.lblIDlabel.AutoSize = true;
            this.lblIDlabel.BackColor = System.Drawing.Color.Transparent;
            this.lblIDlabel.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblIDlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblIDlabel.Location = new System.Drawing.Point(249, 48);
            this.lblIDlabel.Name = "lblIDlabel";
            this.lblIDlabel.Size = new System.Drawing.Size(35, 27);
            this.lblIDlabel.TabIndex = 3;
            this.lblIDlabel.Text = "ID";
            this.lblIDlabel.Click += new System.EventHandler(this.lblIDlabel_Click);
            // 
            // lblCustomerlabel
            // 
            this.lblCustomerlabel.AutoSize = true;
            this.lblCustomerlabel.BackColor = System.Drawing.Color.Transparent;
            this.lblCustomerlabel.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblCustomerlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCustomerlabel.Location = new System.Drawing.Point(22, 50);
            this.lblCustomerlabel.Name = "lblCustomerlabel";
            this.lblCustomerlabel.Size = new System.Drawing.Size(98, 27);
            this.lblCustomerlabel.TabIndex = 2;
            this.lblCustomerlabel.Text = "Surname";
            this.lblCustomerlabel.Click += new System.EventHandler(this.lblCustomerlabel_Click);
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.Thistle;
            this.txtID.Font = new System.Drawing.Font("Tahoma", 14F);
            this.txtID.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtID.Location = new System.Drawing.Point(254, 78);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(192, 30);
            this.txtID.TabIndex = 1;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // txtSurname
            // 
            this.txtSurname.BackColor = System.Drawing.Color.Thistle;
            this.txtSurname.Font = new System.Drawing.Font("Tahoma", 14F);
            this.txtSurname.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtSurname.Location = new System.Drawing.Point(27, 78);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(192, 30);
            this.txtSurname.TabIndex = 0;
            this.txtSurname.TextChanged += new System.EventHandler(this.txtSurname_TextChanged);
            // 
            // GboxEditDetails
            // 
            this.GboxEditDetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GboxEditDetails.BackgroundImage")));
            this.GboxEditDetails.Controls.Add(this.btnRtrnToMM);
            this.GboxEditDetails.Controls.Add(this.cboxSize);
            this.GboxEditDetails.Controls.Add(this.lblSize);
            this.GboxEditDetails.Controls.Add(this.DTPickerDOB);
            this.GboxEditDetails.Controls.Add(this.btnSaveChanges);
            this.GboxEditDetails.Controls.Add(this.cboxtitle);
            this.GboxEditDetails.Controls.Add(this.txtContactNo);
            this.GboxEditDetails.Controls.Add(this.lblContactNumber);
            this.GboxEditDetails.Controls.Add(this.txtEmail);
            this.GboxEditDetails.Controls.Add(this.txtPostCode);
            this.GboxEditDetails.Controls.Add(this.txtTown);
            this.GboxEditDetails.Controls.Add(this.txtAddress);
            this.GboxEditDetails.Controls.Add(this.txtLastN);
            this.GboxEditDetails.Controls.Add(this.txtFirstN);
            this.GboxEditDetails.Controls.Add(this.lblAddress);
            this.GboxEditDetails.Controls.Add(this.lblFirstName);
            this.GboxEditDetails.Controls.Add(this.lblTown);
            this.GboxEditDetails.Controls.Add(this.lblLastName);
            this.GboxEditDetails.Controls.Add(this.lblPostCode);
            this.GboxEditDetails.Controls.Add(this.label2);
            this.GboxEditDetails.Controls.Add(this.lblEmail);
            this.GboxEditDetails.Controls.Add(this.lblTitle);
            this.GboxEditDetails.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GboxEditDetails.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.GboxEditDetails.Location = new System.Drawing.Point(12, 295);
            this.GboxEditDetails.Name = "GboxEditDetails";
            this.GboxEditDetails.Size = new System.Drawing.Size(1066, 257);
            this.GboxEditDetails.TabIndex = 26;
            this.GboxEditDetails.TabStop = false;
            this.GboxEditDetails.Text = "Edit Selected Customer: ";
            // 
            // cboxSize
            // 
            this.cboxSize.BackColor = System.Drawing.Color.Thistle;
            this.cboxSize.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxSize.FormattingEnabled = true;
            this.cboxSize.Items.AddRange(new object[] {
            "Small",
            "Medium",
            "Large",
            "X-Large"});
            this.cboxSize.Location = new System.Drawing.Point(915, 74);
            this.cboxSize.Name = "cboxSize";
            this.cboxSize.Size = new System.Drawing.Size(135, 31);
            this.cboxSize.TabIndex = 21;
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.BackColor = System.Drawing.Color.Transparent;
            this.lblSize.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblSize.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSize.Location = new System.Drawing.Point(910, 46);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(51, 27);
            this.lblSize.TabIndex = 20;
            this.lblSize.Text = "Size";
            // 
            // DTPickerDOB
            // 
            this.DTPickerDOB.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTPickerDOB.Location = new System.Drawing.Point(464, 76);
            this.DTPickerDOB.Name = "DTPickerDOB";
            this.DTPickerDOB.Size = new System.Drawing.Size(210, 30);
            this.DTPickerDOB.TabIndex = 19;
            // 
            // btnSaveChanges
            // 
            this.btnSaveChanges.BackColor = System.Drawing.Color.DeepPink;
            this.btnSaveChanges.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveChanges.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSaveChanges.Location = new System.Drawing.Point(875, 131);
            this.btnSaveChanges.Name = "btnSaveChanges";
            this.btnSaveChanges.Size = new System.Drawing.Size(169, 48);
            this.btnSaveChanges.TabIndex = 18;
            this.btnSaveChanges.Text = "Save";
            this.btnSaveChanges.UseVisualStyleBackColor = false;
            this.btnSaveChanges.Click += new System.EventHandler(this.btnSaveChanges_Click);
            // 
            // cboxtitle
            // 
            this.cboxtitle.BackColor = System.Drawing.Color.Thistle;
            this.cboxtitle.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboxtitle.FormattingEnabled = true;
            this.cboxtitle.Location = new System.Drawing.Point(31, 75);
            this.cboxtitle.Name = "cboxtitle";
            this.cboxtitle.Size = new System.Drawing.Size(121, 31);
            this.cboxtitle.TabIndex = 17;
            // 
            // txtContactNo
            // 
            this.txtContactNo.BackColor = System.Drawing.Color.Thistle;
            this.txtContactNo.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactNo.Location = new System.Drawing.Point(692, 75);
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.Size = new System.Drawing.Size(202, 30);
            this.txtContactNo.TabIndex = 16;
            // 
            // lblContactNumber
            // 
            this.lblContactNumber.AutoSize = true;
            this.lblContactNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblContactNumber.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblContactNumber.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblContactNumber.Location = new System.Drawing.Point(688, 45);
            this.lblContactNumber.Name = "lblContactNumber";
            this.lblContactNumber.Size = new System.Drawing.Size(169, 27);
            this.lblContactNumber.TabIndex = 15;
            this.lblContactNumber.Text = "Contact Number";
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.Thistle;
            this.txtEmail.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(597, 182);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(260, 30);
            this.txtEmail.TabIndex = 14;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // txtPostCode
            // 
            this.txtPostCode.BackColor = System.Drawing.Color.Thistle;
            this.txtPostCode.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPostCode.Location = new System.Drawing.Point(410, 182);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(159, 30);
            this.txtPostCode.TabIndex = 13;
            this.txtPostCode.TextChanged += new System.EventHandler(this.txtPostCode_TextChanged);
            // 
            // txtTown
            // 
            this.txtTown.BackColor = System.Drawing.Color.Thistle;
            this.txtTown.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTown.Location = new System.Drawing.Point(254, 182);
            this.txtTown.Name = "txtTown";
            this.txtTown.Size = new System.Drawing.Size(131, 30);
            this.txtTown.TabIndex = 12;
            this.txtTown.TextChanged += new System.EventHandler(this.txtTown_TextChanged);
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.Thistle;
            this.txtAddress.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(31, 182);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(196, 30);
            this.txtAddress.TabIndex = 11;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
            // 
            // txtLastN
            // 
            this.txtLastN.BackColor = System.Drawing.Color.Thistle;
            this.txtLastN.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastN.Location = new System.Drawing.Point(317, 77);
            this.txtLastN.Name = "txtLastN";
            this.txtLastN.Size = new System.Drawing.Size(128, 30);
            this.txtLastN.TabIndex = 9;
            // 
            // txtFirstN
            // 
            this.txtFirstN.BackColor = System.Drawing.Color.Thistle;
            this.txtFirstN.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstN.Location = new System.Drawing.Point(172, 76);
            this.txtFirstN.Name = "txtFirstN";
            this.txtFirstN.Size = new System.Drawing.Size(128, 30);
            this.txtFirstN.TabIndex = 8;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddress.Location = new System.Drawing.Point(26, 152);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(89, 27);
            this.lblAddress.TabIndex = 7;
            this.lblAddress.Text = "Address";
            this.lblAddress.Click += new System.EventHandler(this.lblAddress_Click);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstName.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblFirstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirstName.Location = new System.Drawing.Point(167, 46);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(117, 27);
            this.lblFirstName.TabIndex = 6;
            this.lblFirstName.Text = "First Name";
            this.lblFirstName.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblTown
            // 
            this.lblTown.AutoSize = true;
            this.lblTown.BackColor = System.Drawing.Color.Transparent;
            this.lblTown.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblTown.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTown.Location = new System.Drawing.Point(249, 152);
            this.lblTown.Name = "lblTown";
            this.lblTown.Size = new System.Drawing.Size(65, 27);
            this.lblTown.TabIndex = 5;
            this.lblTown.Text = "Town";
            this.lblTown.Click += new System.EventHandler(this.lblTown_Click);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.BackColor = System.Drawing.Color.Transparent;
            this.lblLastName.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblLastName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLastName.Location = new System.Drawing.Point(312, 47);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(116, 27);
            this.lblLastName.TabIndex = 4;
            this.lblLastName.Text = "Last Name";
            // 
            // lblPostCode
            // 
            this.lblPostCode.AutoSize = true;
            this.lblPostCode.BackColor = System.Drawing.Color.Transparent;
            this.lblPostCode.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblPostCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPostCode.Location = new System.Drawing.Point(405, 152);
            this.lblPostCode.Name = "lblPostCode";
            this.lblPostCode.Size = new System.Drawing.Size(102, 27);
            this.lblPostCode.TabIndex = 3;
            this.lblPostCode.Text = "PostCode";
            this.lblPostCode.Click += new System.EventHandler(this.lblPostCode_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 16F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(474, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "Date of Birth";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmail.Location = new System.Drawing.Point(593, 152);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(155, 27);
            this.lblEmail.TabIndex = 1;
            this.lblEmail.Text = "E-Mail Address";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTitle.Location = new System.Drawing.Point(26, 45);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(54, 27);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Title";
            // 
            // btnRtrnToMM
            // 
            this.btnRtrnToMM.BackColor = System.Drawing.Color.DeepPink;
            this.btnRtrnToMM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRtrnToMM.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnRtrnToMM.Location = new System.Drawing.Point(875, 185);
            this.btnRtrnToMM.Name = "btnRtrnToMM";
            this.btnRtrnToMM.Size = new System.Drawing.Size(169, 48);
            this.btnRtrnToMM.TabIndex = 22;
            this.btnRtrnToMM.Text = "Return To Main Menu";
            this.btnRtrnToMM.UseVisualStyleBackColor = false;
            this.btnRtrnToMM.Click += new System.EventHandler(this.btnRtrnToMM_Click);
            // 
            // frmEditCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1090, 570);
            this.Controls.Add(this.GboxEditDetails);
            this.Controls.Add(this.GboxSearchBy);
            this.Controls.Add(this.lblAddCusFormTitle);
            this.Name = "frmEditCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Customers";
            this.GboxSearchBy.ResumeLayout(false);
            this.GboxSearchBy.PerformLayout();
            this.GboxEditDetails.ResumeLayout(false);
            this.GboxEditDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddCusFormTitle;
        private System.Windows.Forms.GroupBox GboxSearchBy;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.Label lblIDlabel;
        private System.Windows.Forms.Label lblCustomerlabel;
        private System.Windows.Forms.GroupBox GboxEditDetails;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblTown;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblPostCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.TextBox txtTown;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtLastN;
        private System.Windows.Forms.TextBox txtFirstN;
        private System.Windows.Forms.ComboBox cboxtitle;
        private System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.Label lblContactNumber;
        private System.Windows.Forms.Button btnSaveChanges;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DateTimePicker DTPickerDOB;
        private System.Windows.Forms.ListBox lBoxListResults;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.ComboBox cboxSize;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.Button btnRtrnToMM;
    }
}