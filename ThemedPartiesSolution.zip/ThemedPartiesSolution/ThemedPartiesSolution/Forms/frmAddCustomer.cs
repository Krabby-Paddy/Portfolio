﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;
using ThemedPartiesSolution.DBAccess;

namespace ThemedPartiesSolution
{
    public partial class frmAddCustomer : Form
    {
        private Database db;
        public frmAddCustomer(Database db)
        {
            this.db = db;
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Customer newCust = new Customer();
            newCust.Title = cboxTitle.Text;
            newCust.Address = txtAddress.Text;
            newCust.ContactNo = txtContactNumber.Text;
            newCust.Email = txtEmail.Text;
            newCust.FirstName = txtFirstName.Text;
            newCust.LastName = txtLastName.Text;
            newCust.PostCode = txtPostCode.Text;
            newCust.Town = txtTown.Text;
            newCust.DOB = DtpDOB.Value;
            newCust.Size = cBoxSize.Text;

            if (Objects.Errors.ErrorMessagesFlag == false)
            {
                DBAccess.CustomerDBAccess cus = new DBAccess.CustomerDBAccess(db);
                cus.InsertCustomer(newCust.Title, newCust.FirstName, newCust.LastName, newCust.ContactNo, newCust.Address, newCust.Town, newCust.PostCode, newCust.Email, newCust.DOB, newCust.Size);
                MessageBox.Show("New Customer Added");
                txtAddress.Text = null;
                txtFirstName.Text = null;
                txtLastName.Text = null;
                txtContactNumber.Text = null;
                txtEmail.Text = null;
                cboxTitle.Text = null;
                txtTown.Text = null;
                txtPostCode.Text = null;
                DtpDOB.Text = null;
                cBoxSize = null;
            }
            else if (Objects.Errors.ErrorMessagesFlag == true)
            {
                frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
            }
        }


        private void frmAddCustomer_Load(object sender, EventArgs e){}private void groupBox3_Enter(object sender, EventArgs e){}

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 MM = new Form1(db); 
            this.Hide(); 
            MM.Show();
        }
    }
}
