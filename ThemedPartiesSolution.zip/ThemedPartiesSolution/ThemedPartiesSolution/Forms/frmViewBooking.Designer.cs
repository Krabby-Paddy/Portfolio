﻿namespace ThemedPartiesSolution.Forms
{
    partial class frmViewBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblViewFormHeading = new System.Windows.Forms.Label();
            this.lblBookingID = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblTOE = new System.Windows.Forms.Label();
            this.lblDOE = new System.Windows.Forms.Label();
            this.lblTheme = new System.Windows.Forms.Label();
            this.lblLcustomer = new System.Windows.Forms.Label();
            this.lblLcustomer1 = new System.Windows.Forms.Label();
            this.lblTheme1 = new System.Windows.Forms.Label();
            this.lblDOE1 = new System.Windows.Forms.Label();
            this.lblTOE1 = new System.Windows.Forms.Label();
            this.lblDOB1 = new System.Windows.Forms.Label();
            this.lblBookingID1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblAtt = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblViewFormHeading
            // 
            this.lblViewFormHeading.AutoSize = true;
            this.lblViewFormHeading.BackColor = System.Drawing.Color.Transparent;
            this.lblViewFormHeading.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewFormHeading.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblViewFormHeading.Location = new System.Drawing.Point(29, 45);
            this.lblViewFormHeading.Name = "lblViewFormHeading";
            this.lblViewFormHeading.Size = new System.Drawing.Size(206, 39);
            this.lblViewFormHeading.TabIndex = 0;
            this.lblViewFormHeading.Text = "View Booking";
            // 
            // lblBookingID
            // 
            this.lblBookingID.AutoSize = true;
            this.lblBookingID.BackColor = System.Drawing.Color.Transparent;
            this.lblBookingID.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblBookingID.Location = new System.Drawing.Point(32, 150);
            this.lblBookingID.Name = "lblBookingID";
            this.lblBookingID.Size = new System.Drawing.Size(122, 25);
            this.lblBookingID.TabIndex = 1;
            this.lblBookingID.Text = "Booking ID:";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.BackColor = System.Drawing.Color.Transparent;
            this.lblDOB.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOB.Location = new System.Drawing.Point(32, 210);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(168, 25);
            this.lblDOB.TabIndex = 2;
            this.lblDOB.Text = "Date of Booking:";
            // 
            // lblTOE
            // 
            this.lblTOE.AutoSize = true;
            this.lblTOE.BackColor = System.Drawing.Color.Transparent;
            this.lblTOE.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTOE.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTOE.Location = new System.Drawing.Point(417, 272);
            this.lblTOE.Name = "lblTOE";
            this.lblTOE.Size = new System.Drawing.Size(149, 25);
            this.lblTOE.TabIndex = 3;
            this.lblTOE.Text = "Time of Event:";
            // 
            // lblDOE
            // 
            this.lblDOE.AutoSize = true;
            this.lblDOE.BackColor = System.Drawing.Color.Transparent;
            this.lblDOE.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOE.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOE.Location = new System.Drawing.Point(32, 270);
            this.lblDOE.Name = "lblDOE";
            this.lblDOE.Size = new System.Drawing.Size(146, 25);
            this.lblDOE.TabIndex = 4;
            this.lblDOE.Text = "Date of Event:";
            // 
            // lblTheme
            // 
            this.lblTheme.AutoSize = true;
            this.lblTheme.BackColor = System.Drawing.Color.Transparent;
            this.lblTheme.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTheme.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTheme.Location = new System.Drawing.Point(417, 212);
            this.lblTheme.Name = "lblTheme";
            this.lblTheme.Size = new System.Drawing.Size(83, 25);
            this.lblTheme.TabIndex = 5;
            this.lblTheme.Text = "Theme:";
            // 
            // lblLcustomer
            // 
            this.lblLcustomer.AutoSize = true;
            this.lblLcustomer.BackColor = System.Drawing.Color.Transparent;
            this.lblLcustomer.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcustomer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLcustomer.Location = new System.Drawing.Point(417, 152);
            this.lblLcustomer.Name = "lblLcustomer";
            this.lblLcustomer.Size = new System.Drawing.Size(159, 25);
            this.lblLcustomer.TabIndex = 6;
            this.lblLcustomer.Text = "Lead Customer:";
            this.lblLcustomer.UseMnemonic = false;
            // 
            // lblLcustomer1
            // 
            this.lblLcustomer1.AutoSize = true;
            this.lblLcustomer1.BackColor = System.Drawing.Color.Transparent;
            this.lblLcustomer1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcustomer1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblLcustomer1.Location = new System.Drawing.Point(582, 154);
            this.lblLcustomer1.Name = "lblLcustomer1";
            this.lblLcustomer1.Size = new System.Drawing.Size(59, 23);
            this.lblLcustomer1.TabIndex = 12;
            this.lblLcustomer1.Text = "label7";
            // 
            // lblTheme1
            // 
            this.lblTheme1.AutoSize = true;
            this.lblTheme1.BackColor = System.Drawing.Color.Transparent;
            this.lblTheme1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTheme1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblTheme1.Location = new System.Drawing.Point(506, 214);
            this.lblTheme1.Name = "lblTheme1";
            this.lblTheme1.Size = new System.Drawing.Size(59, 23);
            this.lblTheme1.TabIndex = 11;
            this.lblTheme1.Text = "label8";
            // 
            // lblDOE1
            // 
            this.lblDOE1.AutoSize = true;
            this.lblDOE1.BackColor = System.Drawing.Color.Transparent;
            this.lblDOE1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOE1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblDOE1.Location = new System.Drawing.Point(184, 272);
            this.lblDOE1.Name = "lblDOE1";
            this.lblDOE1.Size = new System.Drawing.Size(59, 23);
            this.lblDOE1.TabIndex = 10;
            this.lblDOE1.Text = "label9";
            // 
            // lblTOE1
            // 
            this.lblTOE1.AutoSize = true;
            this.lblTOE1.BackColor = System.Drawing.Color.Transparent;
            this.lblTOE1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTOE1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblTOE1.Location = new System.Drawing.Point(572, 274);
            this.lblTOE1.Name = "lblTOE1";
            this.lblTOE1.Size = new System.Drawing.Size(69, 23);
            this.lblTOE1.TabIndex = 9;
            this.lblTOE1.Text = "label10";
            // 
            // lblDOB1
            // 
            this.lblDOB1.AutoSize = true;
            this.lblDOB1.BackColor = System.Drawing.Color.Transparent;
            this.lblDOB1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblDOB1.Location = new System.Drawing.Point(206, 212);
            this.lblDOB1.Name = "lblDOB1";
            this.lblDOB1.Size = new System.Drawing.Size(69, 23);
            this.lblDOB1.TabIndex = 8;
            this.lblDOB1.Text = "label11";
            // 
            // lblBookingID1
            // 
            this.lblBookingID1.AutoSize = true;
            this.lblBookingID1.BackColor = System.Drawing.Color.Transparent;
            this.lblBookingID1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBookingID1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblBookingID1.Location = new System.Drawing.Point(160, 152);
            this.lblBookingID1.Name = "lblBookingID1";
            this.lblBookingID1.Size = new System.Drawing.Size(69, 23);
            this.lblBookingID1.TabIndex = 7;
            this.lblBookingID1.Text = "label12";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Thistle;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(35, 389);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(465, 173);
            this.listBox1.TabIndex = 13;
            // 
            // lblAtt
            // 
            this.lblAtt.AutoSize = true;
            this.lblAtt.BackColor = System.Drawing.Color.Transparent;
            this.lblAtt.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtt.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAtt.Location = new System.Drawing.Point(31, 351);
            this.lblAtt.Name = "lblAtt";
            this.lblAtt.Size = new System.Drawing.Size(112, 25);
            this.lblAtt.TabIndex = 14;
            this.lblAtt.Text = "Attendees:";
            this.lblAtt.UseMnemonic = false;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.DeepPink;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Location = new System.Drawing.Point(538, 418);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(255, 47);
            this.btnEdit.TabIndex = 15;
            this.btnEdit.Text = "Edit this Booking";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.DeepPink;
            this.btnReturn.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnReturn.Location = new System.Drawing.Point(538, 471);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(255, 47);
            this.btnReturn.TabIndex = 16;
            this.btnReturn.Text = "Return to Booking Menu";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // frmViewBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ThemedPartiesSolution.Properties.Resources.Untitled_3;
            this.ClientSize = new System.Drawing.Size(822, 600);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblAtt);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblLcustomer1);
            this.Controls.Add(this.lblTheme1);
            this.Controls.Add(this.lblDOE1);
            this.Controls.Add(this.lblTOE1);
            this.Controls.Add(this.lblDOB1);
            this.Controls.Add(this.lblBookingID1);
            this.Controls.Add(this.lblLcustomer);
            this.Controls.Add(this.lblTheme);
            this.Controls.Add(this.lblDOE);
            this.Controls.Add(this.lblTOE);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.lblBookingID);
            this.Controls.Add(this.lblViewFormHeading);
            this.Name = "frmViewBooking";
            this.Text = "                                                                                 " +
    "                                               ";
            this.Load += new System.EventHandler(this.frmViewBooking_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblViewFormHeading;
        private System.Windows.Forms.Label lblBookingID;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblTOE;
        private System.Windows.Forms.Label lblDOE;
        private System.Windows.Forms.Label lblTheme;
        private System.Windows.Forms.Label lblLcustomer;
        private System.Windows.Forms.Label lblLcustomer1;
        private System.Windows.Forms.Label lblTheme1;
        private System.Windows.Forms.Label lblDOE1;
        private System.Windows.Forms.Label lblTOE1;
        private System.Windows.Forms.Label lblDOB1;
        private System.Windows.Forms.Label lblBookingID1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblAtt;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnReturn;
    }
}