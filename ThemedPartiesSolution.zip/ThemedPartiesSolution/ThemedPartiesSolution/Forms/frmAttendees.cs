﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution
{
    public partial class frmAttendees : Form
    {
        bool edit;
        string role;
        List<string> allRoles = new List<string>(){"mrGreen", "mrsWhite", "mrsPeacock", "mmeRose", "missPeach", "mBrunette", "missScarlet", "profPlum", "colonelMustard", "sgtGray"};
        int TabID =0;
        IList<Customer> attending = new List<Customer>();
        private Database db;
        List<ComboBox> cboxList;
        CustomerDBAccess CDBA;
        int bookingID, leadCustomerID;
        AttendeeDBAccess ADBA;
        BookingDBAccess BDA;
        Booking currentBooking;
        Customer leadCustomer;
        Customer AddedCust;
        List<Costume> availableCost = new List<Costume>();
        List<string> selectedCharacters = new List<string>();
        IList<ComboBox> _cboxes = new List<ComboBox>();
        IList<PictureBox> _pboxes = new List<PictureBox>();
        IList<ListBox> _lBoxes = new List<ListBox>();
        IList<Label> _custIDS = new List<Label>();
        CostumeDBAccess CDA;
        Booking newbooking;
        public frmAttendees(Database db, int BookingID, bool edit)
        {
            this.edit = edit;
            this.db = db;
            bookingID = BookingID;
            CDBA = new CustomerDBAccess(db);
            ADBA = new AttendeeDBAccess(db);
            BDA = new BookingDBAccess(db);
            CDA = new CostumeDBAccess(db);
            currentBooking = BDA.getBookingByID(bookingID);
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            updateAttendeesListBox(CDBA.getAttendees(bookingID));
            timer1.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex < 0)
            {
                MessageBox.Show("Please Select a Customer to add to the event.");
            }
            else
            {
                //get customerID from the selected customer in the listbox
                string selected = listBox1.SelectedItem.ToString();
                string[] CustDetails = selected.Split(' ');
                int customerID = Convert.ToInt32(CustDetails[0]);
                ADBA.addAttendee(bookingID, customerID);
                //update attendees listbox
                updateAttendeesListBox(CDBA.getAttendees(bookingID));
                Customer seletcedCust = CDBA.getCustomerByID(customerID);
                createAttendeeTab(seletcedCust);
            }
        }

        private void updateAttendeesListBox(List<Customer> attendees)
        {
            listBox2.Items.Clear();
            for (int i = 0; i < attendees.Count; i++)
            {
                listBox2.Items.Add(attendees[i].CustomerID + " " + attendees[i].FirstName + " " + attendees[i].LastName + " " + attendees[i].Address);
            }

            listBox1.Items.Clear();
            DateTime Date1 = newbooking.DateAndTimeOfEvent;
            string sqlDate = Date1.ToString("yyyy-MM-dd hh:mm:ss.fff");
            List<Customer> customerList = CDBA.wildCardSearch(txtSearchBox.Text, bookingID, sqlDate);

            for (int i = 0; i < customerList.Count; i++)
            {
                if (customerList[i].CustomerID == leadCustomerID) //remove lead customer from the available attendees list
                {
                    customerList.RemoveAt(i);
                }
                else
                {
                    listBox1.Items.Add(customerList[i].CustomerID + " " + customerList[i].FirstName + " " + customerList[i].LastName + " " + customerList[i].Address);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex < 0)
            {
                MessageBox.Show("Please Select a Customer to remove from the event.");
            }
            else
            {  
                string selected = listBox2.SelectedItem.ToString();
                string[] CustDetails = selected.Split(' ');
                int customerID = Convert.ToInt32(CustDetails[0]);
                ADBA.removeAttendee(customerID);
                CustomerDBAccess cdba = new CustomerDBAccess(db);
                Customer removed = cdba.getCustomerByID(customerID);
                updateAttendeesListBox(CDBA.getAttendees(bookingID));
                //remove tabpage when attendee removed
                string tabpage = removed.FirstName + " " + removed.LastName;
                for (int i = 0; i < tabControl1.TabPages.Count; i++)
                {
                    if (tabControl1.TabPages[i].Text.Equals(tabpage, StringComparison.OrdinalIgnoreCase))
                    {
                        tabControl1.TabPages.RemoveAt(i);
                        _cboxes.RemoveAt(i);
                        _custIDS.RemoveAt(i);
                        _lBoxes.RemoveAt(i);
                        _pboxes.RemoveAt(i);
                        break;
                    }
                }
               
            }
        }

        private void createAttendeeTab(Customer addedCust)
        {
            attending.Add(addedCust);
            AddedCust = addedCust;
            //Create a new TabPage

            
            var newTabPage = new TabPage()
            {
                Text = addedCust.FirstName + " " + addedCust.LastName,
                Name= TabID.ToString(),
                BackgroundImage = ThemedPartiesSolution.Properties.Resources.Untitled_3,
            };


            var lbl1 = new Label()
            {
                Text = "Name:",
                Location = new Point(43, 38),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };


            var lbl2 = new Label()
            {
                Name = "lblname",
                Size = new Size (100, 23),
                Text = addedCust.FirstName + " " + addedCust.LastName,
                Location = new Point(235, 38),
                BackColor = Color.Transparent,
                ForeColor = Color.White,

            };

            var lbl3 = new Label()
            {
                Text = "Address:",
                Location = new Point(43, 82),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl4 = new Label()
            {
                Size = new Size(100, 23),
                Name = "lblAddress",
                Text = addedCust.Address,
                Location = new Point(235, 82),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl5 = new Label()
            {
                Text = "Postcode:",
                Location = new Point(43, 130),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl6 = new Label()
            {
                Name = "lblPostCode",
                Size = new Size(100, 23),
                Text = addedCust.PostCode,
                Location = new Point(235, 130),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl7 = new Label()
            {
                Text = "Contact No:",
                Location = new Point(43, 176),
                Size = new Size(109, 23),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl8 = new Label()
            {
                Name = "lblCnum",
                Size = new Size(100, 23),
                Text = addedCust.ContactNo,
                Location = new Point(235, 176),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl9 = new Label()
            {
                Text = "E-Mail:",
                Location = new Point(43, 230),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lbl10 = new Label()
            {
                Name = "lblEmail",
                Text = addedCust.Email,
                Size = new Size(190, 23),
                Location = new Point(235, 230),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var newGroupBox = new GroupBox()
            {
                Text = "Personal Details",
                Location = new Point(18, 33),
                Size = new Size(435, 262),
                ForeColor = Color.White,
                BackgroundImage = Properties.Resources.Untitled_3,
            };

            var newGroupbox1 = new GroupBox()
            {
                Text = "Role/Costume",
                Location = new Point(459, 33),
                Size = new Size(435, 262),
                BackgroundImage = Properties.Resources.Untitled_3,
                ForeColor = Color.White,
            };

            var pbox = new PictureBox()
            {
                Size = new Size(140, 169),
                Location = new Point(23, 58),
                Name = TabID.ToString(),
                BackColor = Color.Transparent,
            };

            var cbox = new ComboBox()
            {
                Location = new Point(262, 74),
                Size = new Size(121, 27),
                Name = TabID.ToString(),
                BackColor = Color.Thistle,
            };

            var lblAvailableCostumes = new Label()
            {
                Location = new Point(190, 140),
                Size = new Size(300, 13),
                Name = "lblAC",
                Text = "Available Costumes: ",
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lblRole = new Label()
            {
                Name = "lblRole",
                Text = "Role:",
                Location = new Point(203, 74),
                Size = new Size(53, 23),
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var lblcustID = new Label()
            {
                Name = TabID.ToString(),
                Text = Convert.ToString(addedCust.CustomerID),
                Visible = false,
                BackColor = Color.Transparent,
                ForeColor = Color.White,
            };

            var Lbox = new ListBox()
            {
                Location = new Point(193, 156),
                Size = new Size(226, 69),
                Name = TabID.ToString(),
                BackColor = Color.Thistle,
                ForeColor = Color.Black,
            };

            var BtnSelect = new Button()
            {
                Location = new Point(23, 233),
                Size = new Size(140, 20),
                Text="Select",
                BackColor = Color.DeepPink,
                ForeColor = Color.Black,
            };
            TabID++;

            BtnSelect.Click += new EventHandler(this.BtnSelect_Click);
            cbox.SelectedIndexChanged += new System.EventHandler(cbox_SelectedValueChanged);
            newGroupBox.Font = new System.Drawing.Font("Tahoma", 12, FontStyle.Bold);
            newGroupBox.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            newGroupbox1.Font = new System.Drawing.Font("Tahoma", 12, FontStyle.Bold);

            newGroupbox1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl3.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl4.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl5.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl7.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl8.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl9.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lbl10.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lblRole.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lblAvailableCostumes.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            Lbox.ForeColor = System.Drawing.ColorTranslator.FromHtml("#000000");

            Lbox.Font      = new System.Drawing.Font("Tahoma", 8);
            lbl1.Font      = new System.Drawing.Font("Tahoma", 14);
            lbl3.Font      = new System.Drawing.Font("Tahoma", 14);
            lbl5.Font      = new System.Drawing.Font("Tahoma", 14);
            lbl7.Font      = new System.Drawing.Font("Tahoma", 14);
            lbl9.Font      = new System.Drawing.Font("Tahoma", 14);
            lbl2.Font      = new System.Drawing.Font("Tahoma", 12);
            lbl4.Font      = new System.Drawing.Font("Tahoma", 12);
            lbl6.Font      = new System.Drawing.Font("Tahoma", 12);
            lbl8.Font      = new System.Drawing.Font("Tahoma", 12);
            lbl10.Font     = new System.Drawing.Font("Tahoma", 12);
            lblRole.Font   = new System.Drawing.Font("Tahoma", 14);
            BtnSelect.Font = new System.Drawing.Font("Tahoma", 8, FontStyle.Bold);
            lblAvailableCostumes.Font = new System.Drawing.Font("Tahoma", 8, FontStyle.Bold);

            newGroupBox.Controls.Add(lbl1);
            newGroupBox.Controls.Add(lbl2);
            newGroupBox.Controls.Add(lbl3);
            newGroupBox.Controls.Add(lbl4);
            newGroupBox.Controls.Add(lbl5);
            newGroupBox.Controls.Add(lbl6);
            newGroupBox.Controls.Add(lbl7);
            newGroupBox.Controls.Add(lbl8);
            newGroupBox.Controls.Add(lbl9);
            newGroupBox.Controls.Add(lbl10);
            newGroupbox1.Controls.Add(lblAvailableCostumes);
            newGroupbox1.Controls.Add(lblRole);
            newGroupbox1.Controls.Add(pbox);
            newGroupbox1.Controls.Add(Lbox);
            newGroupbox1.Controls.Add(cbox);
            _cboxes.Add(cbox);
            _lBoxes.Add(Lbox);
            _pboxes.Add(pbox);
            _custIDS.Add(lblcustID);
            newGroupbox1.Controls.Add(BtnSelect);

            //Assign dynamic handler for the Button's click event
            //newButton.Click += new EventHandler(button_click);

            //Add the Button to the tab page
            newTabPage.Controls.Add(newGroupBox);
            newTabPage.Controls.Add(newGroupbox1);

            //Add the TabPage to the TabControl
            tabControl1.TabPages.Add(newTabPage);
            //sql for available costumes
            //loop to add to cbox
            newbooking = BDA.getBookingByID(bookingID);
            List<int> costIDs = ADBA.getCostumeIDByBookingID(newbooking.BookingID);
            List<Costume> rentedCostumes = new List<Costume>();
            for (int n = 0; n < costIDs.Count;n++)
            {
                rentedCostumes.Add(CDA.getCostumeByID(costIDs[n]));
            }
                //add roles to the combobox
                for (int i = 0; i < allRoles.Count; i++)
                {
                    bool available = true;
                    for (int n = 0; n < rentedCostumes.Count; n++)
                    {
                        if (rentedCostumes[n].Role == allRoles[i])
                        {
                            available = false;
                        }
                    }
                    if (available == true)
                    {
                        cbox.Items.Add(allRoles[i]);
                    }
                }
        } 
        

        private void cbox_SelectedValueChanged(object sender, EventArgs e)
        {
            //display available Costumes
            ComboBox cbox = sender as ComboBox;
            DateTime startTime = newbooking.DateAndTimeOfEvent.AddDays(-7);
            DateTime ReturnTime = newbooking.DateAndTimeOfEvent.AddDays(+7);
            availableCost = CDA.availableCostumes(startTime, ReturnTime); //send start date and end date to search for available costumes
            //TabControl.TabPageCollection pages = tabControl1.TabPages;
            //if (tabControl1.SelectedTab == tabControl1.TabPages["tabname"])
                for (int i = 0; i < _lBoxes.Count; i++)
                {
                    if (_lBoxes[i].Name == tabControl1.SelectedTab.Name)
                    {
                        _lBoxes[i].Items.Clear();
                        for (int n = 0; n < availableCost.Count; n++)
                        {
                            if (cbox.Text == availableCost[n].Role)
                            {
                                _lBoxes[i].Items.Add(availableCost[n].CostumeID + " " + availableCost[n].Role + " " + availableCost[n].Size);
                            }
                        }
                    }
                }
            //get current picturebox
            PictureBox currentPbox = new PictureBox();
            for(int x =0; x<_pboxes.Count; x++)
            {
                if(_pboxes[x].Name == cbox.Name)
                {
                    currentPbox = _pboxes[x];
                }
            }
            //set pictureBox image
            switch(cbox.Text)
            {
                
               case "mBrunette": currentPbox.Image=ThemedPartiesSolution.Properties.Resources.mBrunette0;
                    break;

               case "mrGreen": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrGreen0;
                    break;

               case "mrsWhite": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrsWhite0;
                    break;

               case "mrsPeacock": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrsPeacock0;
                    break;

               case "mmeRose": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mmeRose0;
                    break;

               case "missPeach": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.missPeach0;
                    break;

               case "missScarlet": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.missScarlet0;
                    break;

               case "profPlum": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.profPlum0;
                    break;

               case "colonelMustard": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.colonelMustard0;
                    break;

               case "sgtGray": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.sgtGray0;
                    break;
            }
        }


        protected void BtnSelect_Click(object sender, EventArgs e)
        {
            //display dia box with summary details of booking, including return date of costume etc
            //if yes update attendee
            Button btn = sender as Button;
            int customerID1 =0;
            int costumeID1 = 0;
            int attendID1 =0;
            for (int i = 0; i < _custIDS.Count; i++)
                {
                    if (_custIDS[i].Name == tabControl1.SelectedTab.Name)
                    {
                        customerID1 = Convert.ToInt32(_custIDS[i].Text);
                        Console.WriteLine(_custIDS[i].Name);
                        Console.WriteLine(tabControl1.SelectedTab.Name);
                        Console.WriteLine(_custIDS[i].Name);

                    }
            }
            List<Attendees> addedAttendees = ADBA.getAllAttendeesByBookingID(newbooking.BookingID);
            for(int i=0;i<addedAttendees.Count;i++)
            {
                if(addedAttendees[i].CustomerID == customerID1)
                {
                    attendID1 = addedAttendees[i].AttendeesID;
                }
            }
            for (int i = 0; i < _lBoxes.Count; i++)
                {
                    try 
                  {
                        if (_lBoxes[i].Name == tabControl1.SelectedTab.Name)
                    {
                        string[] costDetails =_lBoxes[i].SelectedItem.ToString().Split(' ');
                        costumeID1 = Convert.ToInt32(costDetails[0]);
                    } 
                  } 
                    
                    catch(Exception)
                    {
                        Objects.Errors.ErrorMessages.Add("Please Select a Costume.");
                        frmErrors Errors = new frmErrors();
                        Errors.Show();
                    }
                    
            }
            DateTime startTime = newbooking.DateAndTimeOfEvent.AddDays(-7);
            DateTime ReturnTime = newbooking.DateAndTimeOfEvent.AddDays(+7);
            ADBA.UpdateAttendee(attendID1, costumeID1);
            CDA.insertRental(attendID1, costumeID1, startTime, ReturnTime);
            TabControl.TabPageCollection pages = tabControl1.TabPages;
            foreach (TabPage page in pages)
            {
                int num = Convert.ToInt32(page.Name);
                _cboxes[num].Items.Clear();
                List<int> costIDs = ADBA.getCostumeIDByBookingID(newbooking.BookingID);
                List<Costume> rentedCostumes = new List<Costume>();
                for (int n = 0; n < costIDs.Count; n++)
                {
                    rentedCostumes.Add(CDA.getCostumeByID(costIDs[n]));
                }
                //add roles to the combobox
                for (int i = 0; i < allRoles.Count; i++)
                {
                    bool available = true;
                    for (int n = 0; n < rentedCostumes.Count; n++)
                    {
                        if (rentedCostumes[n].Role == allRoles[i])
                        {
                            available = false;
                        }
                    }
                    if (available == true)
                    {
                        _cboxes[num].Items.Add(allRoles[i]);
                    }
                }
            }
        }
        
        private void frmAttendees_Load(object sender, EventArgs e)
        {
            TabID = 0;
            if (edit == true)
            {
                List<Customer> editCustomers = new List<Customer>();
                List<Attendees> editAtend = ADBA.getAllAttendeesByBookingID(bookingID);
                for(int i =0; i< editAtend.Count;i++)
                {
                    editCustomers.Add(CDBA.getCustomerByID(editAtend[i].CustomerID));
                    createAttendeeTab(editCustomers[i]);
                }
                updateAttendeesListBox(editCustomers);
                TabControl.TabPageCollection pages = tabControl1.TabPages;
                foreach (TabPage page in pages)
                {
                    //add in the current booking details
                    for(int i =0; i > editAtend.Count; i++)
                    {
                        for(int n =0; n > _custIDS.Count; n++)
                        {
                        if(editAtend[i].CustomerID == Convert.ToInt32(_custIDS[n].Text))
                        {
                            Costume editcost = CDA.getCostumeByID(editAtend[i].CostumeID);
                            _cboxes[i].Text = editcost.Role;
                            PictureBox currentPbox = new PictureBox();
                            for (int x = 0; x < _pboxes.Count; x++)
                            {
                                if (_pboxes[x].Name == _cboxes[i].Name)
                                {
                                    currentPbox = _pboxes[x];
                                }
                            }
                            //set pictureBox image
                            switch (editcost.Role)
                            {
                                case "mBrunette": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mBrunette0;
                                    break;

                                case "mrGreen": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrGreen0;
                                    break;

                                case "mrsWhite": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrsWhite0;
                                    break;

                                case "mrsPeacock": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mrsPeacock0;
                                    break;

                                case "mmeRose": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.mmeRose0;
                                    break;

                                case "missPeach": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.missPeach0;
                                    break;

                                case "missScarlet": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.missScarlet0;
                                    break;

                                case "profPlum": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.profPlum0;
                                    break;

                                case "colonelMustard": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.colonelMustard0;
                                    break;

                                case "sgtGray": currentPbox.Image = ThemedPartiesSolution.Properties.Resources.sgtGray0;
                                    break;
                            }
                            
                        }

                        }
                    }
                    DateTime startTime = newbooking.DateAndTimeOfEvent.AddDays(-7);
                    DateTime ReturnTime = newbooking.DateAndTimeOfEvent.AddDays(+7);
                    availableCost = CDA.availableCostumes(startTime, ReturnTime); //send start date and end date to search for available costumes
                    //TabControl.TabPageCollection pages = tabControl1.TabPages;
                    //if (tabControl1.SelectedTab == tabControl1.TabPages["tabname"])
                    for (int i = 0; i < _lBoxes.Count; i++)
                    {
                        if (_lBoxes[i].Name == page.Name)
                        {
                            _lBoxes[i].Items.Clear();
                            for (int n = 0; n < availableCost.Count; n++)
                            {
                                if (_cboxes[i].Text == availableCost[n].Role)
                                {
                                    _lBoxes[i].Items.Add(availableCost[n].CostumeID + " " + availableCost[n].Role + " " + availableCost[n].Size);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                leadCustomerID = currentBooking.CustomerID;
                leadCustomer = CDBA.getCustomerByID(leadCustomerID);
                createAttendeeTab(leadCustomer);
                ADBA.addAttendee(bookingID, leadCustomerID);
                cboxList = new List<ComboBox>();
                timer2.Start();
            }
            
        }

        private void BtnSelect_Click()
        {}

        private void button3_Click(object sender, EventArgs e) 
        {}

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDialogExit DE = new frmDialogExit();
            DE.Show();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i > _cboxes.Count; i++)
            {
                if (_cboxes[i].Name == "combo" + tabControl1.TabPages[i].Name)
                {
                    switch (_cboxes[i].Text)
                    {
                        case "mBrunette":
                            break;
                    }
                }
            }

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItemRtrnBM_Click(object sender, EventArgs e)
        {
            frmBookingMenu BM = new frmBookingMenu(db);
            BM.Show();
            this.Hide();
        }
    }
}