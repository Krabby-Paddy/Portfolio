﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmSearchBooking : Form
    {
        String Spacing = "{0, -20}{1, -20}{2, -20}";
        private Database db;
        public frmSearchBooking(Database db)
        {
            InitializeComponent();
            this.db = db;
        }

        private void frmSearchBooking_Load(object sender, EventArgs e)
        {
            timer1.Start();
            lBoxListResults.Items.Add(String.Format(Spacing, "Booking ID","Lead Customer", "Date & Time of Event"));
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            lBoxListResults.Font = new System.Drawing.Font("Tahoma", 12);
            try
            {
                switch (cBoxSearchBy.SelectedIndex)
                {
                    case 1: //bookingID
                        bool flag = true;
                        if (txtSearchBox != null)
                        {
                            string TempID = txtSearchBox.Text;
                            for (int i = 0; i > TempID.Length; i++)
                            {
                                if (!char.IsDigit(TempID[i]))
                                {
                                    flag = false;
                                    Errors.ErrorMessages.Add("The ID you have entered is invalid, please try again.");
                                    frmErrors errors = new frmErrors();
                                    Errors.ErrorMessages.Clear();
                                    break;
                                }
                            }
                            if (flag == true)
                            {
                                List<Booking> booking1 = new List<Booking>();
                                Booking findBooking1 = new Booking();
                                BookingDBAccess BDBA1 = new BookingDBAccess(db);
                                int ID = Convert.ToInt32(TempID);
                                findBooking1 = BDBA1.getBookingByID(ID);
                                booking1.Clear();
                                booking1.Add(findBooking1);
                                CustomerDBAccess CDBA = new CustomerDBAccess(db);
                                Customer current = CDBA.getCustomerByID(booking1[0].CustomerID);
                                string CustFullName = (current.FirstName + " " + current.LastName);
                                string dateString2 = booking1[0].DateAndTimeOfEvent.ToShortDateString();
                                string IDno = Convert.ToString(booking1[0].BookingID) + ",";
                                lBoxListResults.Items.Add(String.Format(Spacing, IDno, CustFullName, dateString2)); 
                            }
                            else
                            {
                                Errors.ErrorMessages.Add("Please enter a booking ID.");
                                frmErrors errorsM = new frmErrors();
                                errorsM.Show();
                                //this.Hide();
                            }
                        }
                        break;

                    case 0: //customerID
                        bool flag2 = true;
                        if (txtSearchBox != null)
                        {
                            string TempID = txtSearchBox.Text;
                            for (int i = 0; i > TempID.Length; i++)
                            {
                                if (!char.IsDigit(TempID[i]))
                                {
                                    flag2 = false;
                                    Errors.ErrorMessages.Add("The ID you have entered is invalid, please try again.");
                                    frmErrors errors = new frmErrors();
                                    Errors.ErrorMessages.Clear();
                                    break;
                                }}

                            if (flag2 == true)
                            {
                                List<Booking> booking2 = new List<Booking>();
                                //Booking findBooking2 = new Booking();
                                BookingDBAccess BDBA2 = new BookingDBAccess(db);
                                int ID = Convert.ToInt32(TempID);
                                booking2 = BDBA2.getBookingByCustID(ID);
                                Console.Write(booking2.Count);
                                //booking2.Add(findBooking2);
                                for (int r = 0; r < booking2.Count; r++)
                                {
                                    CustomerDBAccess CDBA = new CustomerDBAccess(db);
                                    Customer current = CDBA.getCustomerByID(booking2[r].CustomerID);
                                    string CustFullName = (current.FirstName + " " + current.LastName);
                                    string dateString2 = booking2[r].DateAndTimeOfEvent.ToShortDateString();
                                    string IDno = Convert.ToString(booking2[r].BookingID) + ",";
                                    lBoxListResults.Items.Add(String.Format(Spacing, IDno, CustFullName, dateString2));
                                }
                            }
                            else
                            {
                                Errors.ErrorMessages.Add("Please enter a booking ID.");
                                frmErrors errorsM = new frmErrors();
                                errorsM.Show();
                            }

                        }
                        break;

                    case 2: //booking Date
                        DateTime date = dtpDOE.Value;
                        List<Booking> booking = new List<Booking>();
                        Booking findBooking = new Booking();
                        BookingDBAccess BDBA = new BookingDBAccess(db);
                        findBooking = BDBA.getBookingByDate(date);
                        booking.Add(findBooking);
                        for (int i = 0; i < booking.Count; i++)
                        {
                            CustomerDBAccess CDBA = new CustomerDBAccess(db);
                            Customer current = CDBA.getCustomerByID(booking[i].CustomerID);
                            string CustFullName = (current.FirstName + " " + current.LastName);
                            string dateString2 = booking[i].DateAndTimeOfEvent.ToShortDateString();
                            string IDno = Convert.ToString(booking[i].BookingID) + ","; 
                            lBoxListResults.Items.Add(String.Format(Spacing, IDno,CustFullName , dateString2));
                        }
                        break;
                }
            }

            catch (Exception)
            {
                Objects.Errors.ErrorMessages.Add("The ID you have entered is invalid, please try again.");
            Objects.Errors.ErrorMessagesFlag = true;
            frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
            }
            }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) { }

        private void cBox_SelectedIndexChanged(object sender, EventArgs e){}

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (cBoxSearchBy.Text == "Booking ID" || cBoxSearchBy.Text == "Customer ID")
            {
                txtSearchBox.Visible = true;
                dtpDOE.Visible = false;
            }
            else if (cBoxSearchBy.Text == "Booking Date")
            {
                txtSearchBox.Visible = false;
                dtpDOE.Visible = true;
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
                int BooID = Convert.ToInt32(selected[0]);
            BookingDBAccess bdba = new BookingDBAccess(db);
            Booking selectedBoo = bdba.getBookingByID(BooID);
            int custID = selectedBoo.CustomerID;
            bool edit = true;
            frmEditBookingMenu EBM = new frmEditBookingMenu(db, custID, edit, BooID);
            EBM.Show();
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
                int BooID = Convert.ToInt32(selected[0]);
                BookingDBAccess bdba = new BookingDBAccess(db);
                bdba.DeleteBookng(BooID);
            }
            catch (Exception)
            {
                Objects.Errors.ErrorMessages.Add("Please select a Booking to delete.");
                Objects.Errors.ErrorMessagesFlag = true;

                frmErrors ErrorMessages = new frmErrors();
                ErrorMessages.Show();


            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
                int BooID = Convert.ToInt32(selected[0]);
                frmViewBooking vb = new frmViewBooking(db, BooID);
                vb.Show();
                this.Hide();
            }
            catch (Exception)
            {
                Objects.Errors.ErrorMessages.Add("Please select a Booking to view.");
                Objects.Errors.ErrorMessagesFlag = true;

                frmErrors ErrorMessages = new frmErrors();
                ErrorMessages.Show();

            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            frmBookingMenu BM = new frmBookingMenu(db);
            BM.Show();
            this.Hide();
        }
    }
}