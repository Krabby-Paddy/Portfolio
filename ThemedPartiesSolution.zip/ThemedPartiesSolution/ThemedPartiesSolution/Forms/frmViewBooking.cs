﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmViewBooking : Form
    {

        private Database db;
        private int BookingID;

        public frmViewBooking(Database db, int BookingID)
        {
            this.db = db;
            this.BookingID = BookingID;
            InitializeComponent();
        }

        private void frmViewBooking_Load(object sender, EventArgs e)
        {
            BookingDBAccess BDBA = new BookingDBAccess(db);
            Booking selected = BDBA.getBookingByID(BookingID);
            CustomerDBAccess CDBA = new CustomerDBAccess(db);
            Customer selectedCust = CDBA.getCustomerByID(selected.CustomerID);
            lblBookingID1.Text = Convert.ToString(selected.BookingID);
            lblDOB1.Text = Convert.ToString(selected.DateOfBooking);
            lblDOE1.Text = Convert.ToString(selected.DateAndTimeOfEvent);
            int custID = selectedCust.CustomerID;
            lblLcustomer1.Text = (selectedCust.FirstName + " " + selectedCust.LastName);
            lblTheme1.Text = selected.Theme;
            if (selected.TimeOfEvent == 1)
            {
                lblTOE1.Text = "6:00pm";
            }
            else
            {
                lblTOE1.Text = "9:00pm";
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmBookingMenu bm = new frmBookingMenu(db);
            bm.Show();
            this.Hide();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            bool edit = true;
             BookingDBAccess BDBA = new BookingDBAccess(db);
            Booking selected = BDBA.getBookingByID(BookingID);
            CustomerDBAccess CDBA = new CustomerDBAccess(db);
            Customer selectedCust = CDBA.getCustomerByID(selected.CustomerID);
            int custID = selectedCust.CustomerID;
            frmEditBookingMenu emb = new frmEditBookingMenu(db, custID, edit, BookingID);
            emb.Show();
            this.Hide();
        }
    }
}
