﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution
{
    public partial class Form1 : Form
    {

        private Database db; 

        public Form1(Database db)
        {
            InitializeComponent();
            this.db = db;
        }


        private void tempbut1_Click(object sender, EventArgs e)
        {
          frmAddCustomer addcus = new frmAddCustomer(db);
          addcus.Show();
          this.Hide();

        }

        private void btnSearchCust_Click(object sender, EventArgs e)
        {
            frmSearchCustomer srchCus = new frmSearchCustomer(db);
            srchCus.Show();
            this.Hide();
        }

        private void searchCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSearchCustomer srchCus = new frmSearchCustomer(db);
            srchCus.Show();
            this.Hide();
            
        }

        private void editCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSearchCustomer srchCus = new frmSearchCustomer(db);
            srchCus.Show();
            this.Hide();
            Control.SelectedSearchType = 1;
        }

        private void searchForCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedID = 0;
            frmEditCustomer editCustomer = new frmEditCustomer(db, selectedID);
            editCustomer.Show();
            this.Hide();
            Control.SelectedSearchType = 2;
        }

        private void btnEditCustomer_Click(object sender, EventArgs e)
        {
            int selectedID = 0;
            frmEditCustomer editCustomer = new frmEditCustomer(db, selectedID);
            editCustomer.Show();
            this.Hide();
            Control.SelectedSearchType = 2;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           frmAttendees att = new frmAttendees(db, 2, true);
           att.Show();
        }

        private void label1_Click(object sender, EventArgs e){}

        private void btnSearchBooking_Click(object sender, EventArgs e)
        {}

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            frmPrimaryMenu pm = new frmPrimaryMenu(db);
            pm.Show();
            this.Hide();
        }
    }
}