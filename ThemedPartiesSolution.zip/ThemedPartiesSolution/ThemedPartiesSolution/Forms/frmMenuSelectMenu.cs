﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmMenuSelectMenu : Form
    {
        private Database db;

        public frmMenuSelectMenu(Database db)
        {
            InitializeComponent();
            this.db = db;
        }

        private void btnThemedP_Click(object sender, EventArgs e)
        {
            frmPrimaryMenu pm = new frmPrimaryMenu(db);
            pm.Show();
            this.Close();
        }

        private void frmMenuSelectMenu_Load(object sender, EventArgs e)
        {
            btnCatering.Enabled = false;
            btnWedding.Enabled = false;
        }
    }
}
