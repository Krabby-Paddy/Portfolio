﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmLoad : Form
    {

        private Database db;

        public frmLoad()
        {
            InitializeComponent();
            db = new Database();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            proBarLoad.PerformStep();
            if (proBarLoad.Value == 100)
            {
                if (db.connect())
                {
                    frmMenuSelectMenu msm = new frmMenuSelectMenu(db);
                    msm.Show();
                    this.Hide();
                    timer1.Stop();
                            }
                            else
                            {
                                frmErrors errorConnecting = new frmErrors();
                                Errors.ErrorMessages.Add("Failed to Connect to database, please try again.");
                                errorConnecting.Show();
                                Errors.ErrorMessages.Clear();
                                this.Hide();
                            }
            }
        }

        private void frmLoad_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
