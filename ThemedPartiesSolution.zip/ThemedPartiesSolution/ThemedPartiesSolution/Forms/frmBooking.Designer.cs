﻿namespace ThemedPartiesSolution
{
    partial class frmBooking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBooking));
            this.gBoxCusDetails = new System.Windows.Forms.GroupBox();
            this.lblFirstN = new System.Windows.Forms.Label();
            this.lblLastN = new System.Windows.Forms.Label();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblTown = new System.Windows.Forms.Label();
            this.lblPostC = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCusPostCode = new System.Windows.Forms.Label();
            this.lblCusDOB = new System.Windows.Forms.Label();
            this.lblCusFirstName = new System.Windows.Forms.Label();
            this.lblCusSecondName = new System.Windows.Forms.Label();
            this.lblCusContactNo = new System.Windows.Forms.Label();
            this.lblCusEmailAddress = new System.Windows.Forms.Label();
            this.lblCusAddress = new System.Windows.Forms.Label();
            this.lblCusTown = new System.Windows.Forms.Label();
            this.lblCusTitle = new System.Windows.Forms.Label();
            this.gBoxBkingDetails = new System.Windows.Forms.GroupBox();
            this.btnRtrnToMM = new System.Windows.Forms.Button();
            this.lblDOB = new System.Windows.Forms.Label();
            this.btnCreateBooking = new System.Windows.Forms.Button();
            this.btnAddAtt = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.chkBmurderM = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chBox9pm = new System.Windows.Forms.CheckBox();
            this.chBox6pm = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDOE = new System.Windows.Forms.DateTimePicker();
            this.lblDaToE = new System.Windows.Forms.Label();
            this.lblDateOfBooking = new System.Windows.Forms.Label();
            this.lblFormtitle = new System.Windows.Forms.Label();
            this.gBoxCusDetails.SuspendLayout();
            this.gBoxBkingDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // gBoxCusDetails
            // 
            this.gBoxCusDetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gBoxCusDetails.BackgroundImage")));
            this.gBoxCusDetails.Controls.Add(this.lblFirstN);
            this.gBoxCusDetails.Controls.Add(this.lblLastN);
            this.gBoxCusDetails.Controls.Add(this.lblContactNo);
            this.gBoxCusDetails.Controls.Add(this.lblEmail);
            this.gBoxCusDetails.Controls.Add(this.lblAddress);
            this.gBoxCusDetails.Controls.Add(this.lblTown);
            this.gBoxCusDetails.Controls.Add(this.lblPostC);
            this.gBoxCusDetails.Controls.Add(this.lblTitle);
            this.gBoxCusDetails.Controls.Add(this.lblCusPostCode);
            this.gBoxCusDetails.Controls.Add(this.lblCusDOB);
            this.gBoxCusDetails.Controls.Add(this.lblCusFirstName);
            this.gBoxCusDetails.Controls.Add(this.lblCusSecondName);
            this.gBoxCusDetails.Controls.Add(this.lblCusContactNo);
            this.gBoxCusDetails.Controls.Add(this.lblCusEmailAddress);
            this.gBoxCusDetails.Controls.Add(this.lblCusAddress);
            this.gBoxCusDetails.Controls.Add(this.lblCusTown);
            this.gBoxCusDetails.Controls.Add(this.lblCusTitle);
            this.gBoxCusDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.gBoxCusDetails.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gBoxCusDetails.Location = new System.Drawing.Point(52, 95);
            this.gBoxCusDetails.Name = "gBoxCusDetails";
            this.gBoxCusDetails.Size = new System.Drawing.Size(258, 479);
            this.gBoxCusDetails.TabIndex = 0;
            this.gBoxCusDetails.TabStop = false;
            this.gBoxCusDetails.Text = "Customer Details";
            this.gBoxCusDetails.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lblFirstN
            // 
            this.lblFirstN.AutoSize = true;
            this.lblFirstN.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstN.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstN.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirstN.Location = new System.Drawing.Point(21, 102);
            this.lblFirstN.Name = "lblFirstN";
            this.lblFirstN.Size = new System.Drawing.Size(75, 16);
            this.lblFirstN.TabIndex = 17;
            this.lblFirstN.Text = "First Name:";
            // 
            // lblLastN
            // 
            this.lblLastN.AutoSize = true;
            this.lblLastN.BackColor = System.Drawing.Color.Transparent;
            this.lblLastN.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastN.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblLastN.Location = new System.Drawing.Point(21, 167);
            this.lblLastN.Name = "lblLastN";
            this.lblLastN.Size = new System.Drawing.Size(73, 16);
            this.lblLastN.TabIndex = 16;
            this.lblLastN.Text = "Last Name:";
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.BackColor = System.Drawing.Color.Transparent;
            this.lblContactNo.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContactNo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblContactNo.Location = new System.Drawing.Point(21, 232);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(75, 16);
            this.lblContactNo.TabIndex = 15;
            this.lblContactNo.Text = "Contact No:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEmail.Location = new System.Drawing.Point(21, 297);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(94, 16);
            this.lblEmail.TabIndex = 14;
            this.lblEmail.Text = "Email Address:";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAddress.Location = new System.Drawing.Point(21, 362);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(59, 16);
            this.lblAddress.TabIndex = 13;
            this.lblAddress.Text = "Address:";
            // 
            // lblTown
            // 
            this.lblTown.AutoSize = true;
            this.lblTown.BackColor = System.Drawing.Color.Transparent;
            this.lblTown.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTown.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTown.Location = new System.Drawing.Point(21, 427);
            this.lblTown.Name = "lblTown";
            this.lblTown.Size = new System.Drawing.Size(45, 16);
            this.lblTown.TabIndex = 12;
            this.lblTown.Text = "Town:";
            // 
            // lblPostC
            // 
            this.lblPostC.AutoSize = true;
            this.lblPostC.BackColor = System.Drawing.Color.Transparent;
            this.lblPostC.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostC.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPostC.Location = new System.Drawing.Point(21, 492);
            this.lblPostC.Name = "lblPostC";
            this.lblPostC.Size = new System.Drawing.Size(70, 16);
            this.lblPostC.TabIndex = 11;
            this.lblPostC.Text = "Post Code:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTitle.Location = new System.Drawing.Point(21, 37);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(38, 16);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Title:";
            // 
            // lblCusPostCode
            // 
            this.lblCusPostCode.AutoSize = true;
            this.lblCusPostCode.BackColor = System.Drawing.Color.Transparent;
            this.lblCusPostCode.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusPostCode.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusPostCode.Location = new System.Drawing.Point(20, 505);
            this.lblCusPostCode.Name = "lblCusPostCode";
            this.lblCusPostCode.Size = new System.Drawing.Size(51, 19);
            this.lblCusPostCode.TabIndex = 8;
            this.lblCusPostCode.Text = "label8";
            // 
            // lblCusDOB
            // 
            this.lblCusDOB.AutoSize = true;
            this.lblCusDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblCusDOB.Location = new System.Drawing.Point(20, 570);
            this.lblCusDOB.Name = "lblCusDOB";
            this.lblCusDOB.Size = new System.Drawing.Size(51, 20);
            this.lblCusDOB.TabIndex = 7;
            this.lblCusDOB.Text = "label7";
            // 
            // lblCusFirstName
            // 
            this.lblCusFirstName.AutoSize = true;
            this.lblCusFirstName.BackColor = System.Drawing.Color.Transparent;
            this.lblCusFirstName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusFirstName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusFirstName.Location = new System.Drawing.Point(20, 115);
            this.lblCusFirstName.Name = "lblCusFirstName";
            this.lblCusFirstName.Size = new System.Drawing.Size(51, 19);
            this.lblCusFirstName.TabIndex = 6;
            this.lblCusFirstName.Text = "label1";
            // 
            // lblCusSecondName
            // 
            this.lblCusSecondName.AutoSize = true;
            this.lblCusSecondName.BackColor = System.Drawing.Color.Transparent;
            this.lblCusSecondName.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusSecondName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusSecondName.Location = new System.Drawing.Point(20, 180);
            this.lblCusSecondName.Name = "lblCusSecondName";
            this.lblCusSecondName.Size = new System.Drawing.Size(51, 19);
            this.lblCusSecondName.TabIndex = 5;
            this.lblCusSecondName.Text = "label1";
            // 
            // lblCusContactNo
            // 
            this.lblCusContactNo.AutoSize = true;
            this.lblCusContactNo.BackColor = System.Drawing.Color.Transparent;
            this.lblCusContactNo.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusContactNo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusContactNo.Location = new System.Drawing.Point(20, 245);
            this.lblCusContactNo.Name = "lblCusContactNo";
            this.lblCusContactNo.Size = new System.Drawing.Size(51, 19);
            this.lblCusContactNo.TabIndex = 4;
            this.lblCusContactNo.Text = "label1";
            // 
            // lblCusEmailAddress
            // 
            this.lblCusEmailAddress.AutoSize = true;
            this.lblCusEmailAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblCusEmailAddress.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusEmailAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusEmailAddress.Location = new System.Drawing.Point(20, 310);
            this.lblCusEmailAddress.Name = "lblCusEmailAddress";
            this.lblCusEmailAddress.Size = new System.Drawing.Size(51, 19);
            this.lblCusEmailAddress.TabIndex = 3;
            this.lblCusEmailAddress.Text = "label1";
            // 
            // lblCusAddress
            // 
            this.lblCusAddress.AutoSize = true;
            this.lblCusAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblCusAddress.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusAddress.Location = new System.Drawing.Point(20, 375);
            this.lblCusAddress.Name = "lblCusAddress";
            this.lblCusAddress.Size = new System.Drawing.Size(51, 19);
            this.lblCusAddress.TabIndex = 2;
            this.lblCusAddress.Text = "label1";
            // 
            // lblCusTown
            // 
            this.lblCusTown.AutoSize = true;
            this.lblCusTown.BackColor = System.Drawing.Color.Transparent;
            this.lblCusTown.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusTown.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusTown.Location = new System.Drawing.Point(20, 440);
            this.lblCusTown.Name = "lblCusTown";
            this.lblCusTown.Size = new System.Drawing.Size(51, 19);
            this.lblCusTown.TabIndex = 1;
            this.lblCusTown.Text = "label1";
            // 
            // lblCusTitle
            // 
            this.lblCusTitle.AutoSize = true;
            this.lblCusTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblCusTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCusTitle.Location = new System.Drawing.Point(20, 50);
            this.lblCusTitle.Name = "lblCusTitle";
            this.lblCusTitle.Size = new System.Drawing.Size(51, 19);
            this.lblCusTitle.TabIndex = 0;
            this.lblCusTitle.Text = "label1";
            // 
            // gBoxBkingDetails
            // 
            this.gBoxBkingDetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gBoxBkingDetails.BackgroundImage")));
            this.gBoxBkingDetails.Controls.Add(this.btnRtrnToMM);
            this.gBoxBkingDetails.Controls.Add(this.lblDOB);
            this.gBoxBkingDetails.Controls.Add(this.btnCreateBooking);
            this.gBoxBkingDetails.Controls.Add(this.btnAddAtt);
            this.gBoxBkingDetails.Controls.Add(this.checkBox1);
            this.gBoxBkingDetails.Controls.Add(this.chkBmurderM);
            this.gBoxBkingDetails.Controls.Add(this.label2);
            this.gBoxBkingDetails.Controls.Add(this.chBox9pm);
            this.gBoxBkingDetails.Controls.Add(this.chBox6pm);
            this.gBoxBkingDetails.Controls.Add(this.label1);
            this.gBoxBkingDetails.Controls.Add(this.dtpDOE);
            this.gBoxBkingDetails.Controls.Add(this.lblDaToE);
            this.gBoxBkingDetails.Controls.Add(this.lblDateOfBooking);
            this.gBoxBkingDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.gBoxBkingDetails.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gBoxBkingDetails.Location = new System.Drawing.Point(341, 95);
            this.gBoxBkingDetails.Name = "gBoxBkingDetails";
            this.gBoxBkingDetails.Size = new System.Drawing.Size(258, 479);
            this.gBoxBkingDetails.TabIndex = 1;
            this.gBoxBkingDetails.TabStop = false;
            this.gBoxBkingDetails.Text = "Booking Details";
            // 
            // btnRtrnToMM
            // 
            this.btnRtrnToMM.BackColor = System.Drawing.Color.DeepPink;
            this.btnRtrnToMM.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRtrnToMM.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnRtrnToMM.Location = new System.Drawing.Point(49, 426);
            this.btnRtrnToMM.Name = "btnRtrnToMM";
            this.btnRtrnToMM.Size = new System.Drawing.Size(162, 31);
            this.btnRtrnToMM.TabIndex = 35;
            this.btnRtrnToMM.Text = "Return to Main Menu";
            this.btnRtrnToMM.UseVisualStyleBackColor = false;
            this.btnRtrnToMM.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.BackColor = System.Drawing.Color.Transparent;
            this.lblDOB.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDOB.Location = new System.Drawing.Point(23, 62);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(51, 19);
            this.lblDOB.TabIndex = 34;
            this.lblDOB.Text = "label3";
            // 
            // btnCreateBooking
            // 
            this.btnCreateBooking.BackColor = System.Drawing.Color.DeepPink;
            this.btnCreateBooking.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateBooking.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCreateBooking.Location = new System.Drawing.Point(49, 346);
            this.btnCreateBooking.Name = "btnCreateBooking";
            this.btnCreateBooking.Size = new System.Drawing.Size(162, 31);
            this.btnCreateBooking.TabIndex = 33;
            this.btnCreateBooking.Text = "Create New Booking";
            this.btnCreateBooking.UseVisualStyleBackColor = false;
            this.btnCreateBooking.Click += new System.EventHandler(this.btnCreateAtt_Click);
            // 
            // btnAddAtt
            // 
            this.btnAddAtt.BackColor = System.Drawing.Color.DeepPink;
            this.btnAddAtt.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddAtt.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAddAtt.Location = new System.Drawing.Point(49, 386);
            this.btnAddAtt.Name = "btnAddAtt";
            this.btnAddAtt.Size = new System.Drawing.Size(162, 31);
            this.btnAddAtt.TabIndex = 32;
            this.btnAddAtt.Text = "Add Attendees";
            this.btnAddAtt.UseVisualStyleBackColor = false;
            this.btnAddAtt.Click += new System.EventHandler(this.btnAddAtt_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.Enabled = false;
            this.checkBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.checkBox1.Location = new System.Drawing.Point(16, 295);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(127, 23);
            this.checkBox1.TabIndex = 31;
            this.checkBox1.Text = "Birthday Party";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chkBmurderM
            // 
            this.chkBmurderM.AutoSize = true;
            this.chkBmurderM.BackColor = System.Drawing.Color.Transparent;
            this.chkBmurderM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBmurderM.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkBmurderM.Location = new System.Drawing.Point(16, 271);
            this.chkBmurderM.Name = "chkBmurderM";
            this.chkBmurderM.Size = new System.Drawing.Size(137, 23);
            this.chkBmurderM.TabIndex = 30;
            this.chkBmurderM.Text = "Murder Mystery";
            this.chkBmurderM.UseVisualStyleBackColor = false;
            this.chkBmurderM.CheckedChanged += new System.EventHandler(this.chkBmurderM_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(23, 245);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "Theme of Event:";
            // 
            // chBox9pm
            // 
            this.chBox9pm.AutoSize = true;
            this.chBox9pm.BackColor = System.Drawing.Color.Transparent;
            this.chBox9pm.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chBox9pm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chBox9pm.Location = new System.Drawing.Point(140, 193);
            this.chBox9pm.Name = "chBox9pm";
            this.chBox9pm.Size = new System.Drawing.Size(84, 23);
            this.chBox9pm.TabIndex = 28;
            this.chBox9pm.Text = "9:00pm";
            this.chBox9pm.UseVisualStyleBackColor = false;
            this.chBox9pm.CheckedChanged += new System.EventHandler(this.chBox9pm_CheckedChanged);
            // 
            // chBox6pm
            // 
            this.chBox6pm.AutoSize = true;
            this.chBox6pm.BackColor = System.Drawing.Color.Transparent;
            this.chBox6pm.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chBox6pm.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chBox6pm.Location = new System.Drawing.Point(52, 193);
            this.chBox6pm.Name = "chBox6pm";
            this.chBox6pm.Size = new System.Drawing.Size(84, 23);
            this.chBox6pm.TabIndex = 27;
            this.chBox6pm.Text = "6:00pm";
            this.chBox6pm.UseVisualStyleBackColor = false;
            this.chBox6pm.CheckedChanged += new System.EventHandler(this.chBox6pm_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(23, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "Time of Event:";
            // 
            // dtpDOE
            // 
            this.dtpDOE.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDOE.Location = new System.Drawing.Point(26, 118);
            this.dtpDOE.Name = "dtpDOE";
            this.dtpDOE.Size = new System.Drawing.Size(200, 27);
            this.dtpDOE.TabIndex = 25;
            // 
            // lblDaToE
            // 
            this.lblDaToE.AutoSize = true;
            this.lblDaToE.BackColor = System.Drawing.Color.Transparent;
            this.lblDaToE.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDaToE.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDaToE.Location = new System.Drawing.Point(23, 102);
            this.lblDaToE.Name = "lblDaToE";
            this.lblDaToE.Size = new System.Drawing.Size(89, 16);
            this.lblDaToE.TabIndex = 23;
            this.lblDaToE.Text = "Date of Event:";
            this.lblDaToE.Click += new System.EventHandler(this.lblDaToE_Click);
            // 
            // lblDateOfBooking
            // 
            this.lblDateOfBooking.AutoSize = true;
            this.lblDateOfBooking.BackColor = System.Drawing.Color.Transparent;
            this.lblDateOfBooking.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfBooking.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDateOfBooking.Location = new System.Drawing.Point(23, 37);
            this.lblDateOfBooking.Name = "lblDateOfBooking";
            this.lblDateOfBooking.Size = new System.Drawing.Size(102, 16);
            this.lblDateOfBooking.TabIndex = 21;
            this.lblDateOfBooking.Text = "Date of Booking:";
            // 
            // lblFormtitle
            // 
            this.lblFormtitle.AutoSize = true;
            this.lblFormtitle.BackColor = System.Drawing.Color.Transparent;
            this.lblFormtitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormtitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFormtitle.Location = new System.Drawing.Point(243, 31);
            this.lblFormtitle.Name = "lblFormtitle";
            this.lblFormtitle.Size = new System.Drawing.Size(199, 29);
            this.lblFormtitle.TabIndex = 2;
            this.lblFormtitle.Text = "Create a Booking";
            // 
            // frmBooking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(652, 657);
            this.Controls.Add(this.lblFormtitle);
            this.Controls.Add(this.gBoxBkingDetails);
            this.Controls.Add(this.gBoxCusDetails);
            this.Name = "frmBooking";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Booking";
            this.Load += new System.EventHandler(this.frmBooking_Load);
            this.gBoxCusDetails.ResumeLayout(false);
            this.gBoxCusDetails.PerformLayout();
            this.gBoxBkingDetails.ResumeLayout(false);
            this.gBoxBkingDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gBoxCusDetails;
        private System.Windows.Forms.Label lblCusFirstName;
        private System.Windows.Forms.Label lblCusSecondName;
        private System.Windows.Forms.Label lblCusContactNo;
        private System.Windows.Forms.Label lblCusEmailAddress;
        private System.Windows.Forms.Label lblCusAddress;
        private System.Windows.Forms.Label lblCusTown;
        private System.Windows.Forms.Label lblCusTitle;
        private System.Windows.Forms.GroupBox gBoxBkingDetails;
        private System.Windows.Forms.Label lblCusPostCode;
        private System.Windows.Forms.Label lblCusDOB;
        private System.Windows.Forms.Label lblFirstN;
        private System.Windows.Forms.Label lblLastN;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblTown;
        private System.Windows.Forms.Label lblPostC;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblDaToE;
        private System.Windows.Forms.Label lblDateOfBooking;
        private System.Windows.Forms.DateTimePicker dtpDOE;
        private System.Windows.Forms.CheckBox chBox9pm;
        private System.Windows.Forms.CheckBox chBox6pm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCreateBooking;
        private System.Windows.Forms.Button btnAddAtt;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox chkBmurderM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblFormtitle;
        private System.Windows.Forms.Button btnRtrnToMM;
    }
}