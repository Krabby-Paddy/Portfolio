﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmBookingMenu : Form
    {
        Database db;

        public frmBookingMenu(Database db)
        {
            InitializeComponent();
            this.db = db;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            frmPrimaryMenu pm = new frmPrimaryMenu(db);
            pm.Show();
            this.Hide();
        }

        private void btnSearchCust_Click(object sender, EventArgs e)
        {
            frmSearchBooking sb = new frmSearchBooking(db);
            sb.Show();
            this.Hide();
        }

        private void btnAddCus_Click(object sender, EventArgs e)
        {
            frmSearchCustomer sc = new frmSearchCustomer(db);
            sc.Show();
            this.Hide();
        }

        private void btnEditBoo_Click(object sender, EventArgs e)
        {
            frmSearchBooking sb = new frmSearchBooking(db);
            sb.Show();
            this.Hide();
        }
    }
}