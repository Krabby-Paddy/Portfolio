﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;

namespace ThemedPartiesSolution
{
    public partial class frmEditCustomer : Form
    {
        private Database db;
        private int SelectedID;

        public frmEditCustomer(Database db, int SelectedID){
            InitializeComponent();
            this.db = db;
        }

        private void lblAddCusFormTitle_Click(object sender, EventArgs e){} private void label6_Click(object sender, EventArgs e){}

        private void btnSearch_Click(object sender, EventArgs e){
            btnSelect.Enabled = true;
            lBoxListResults.Items.Clear();
            if (string.IsNullOrWhiteSpace(txtSurname.Text)){
                string TempID = txtID.Text;
                    bool Break = false;
                    for (int i = 0; i > TempID.Length; i++)
                    {
                        if (!char.IsDigit(TempID[i]))
                        {
                            Objects.Errors.ErrorMessages.Add("An invalid Customer ID has been entered");
                            Objects.Errors.ErrorMessagesFlag = true;
                            frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                            txtID.Text = null;
                            Break = true;
                            break;
                        }
                    }
                    if (Break ==true){int id = Convert.ToInt32(txtID.Text);
                    List<Customer> customer = new List<Customer>();
                    Customer findCustomer = new Customer();
                    CustomerDBAccess CdbAccess = new CustomerDBAccess(db);
                    findCustomer = CdbAccess.getCustomerByID(id);
                    customer.Add(findCustomer);
                    if (findCustomer.FirstName == null)
                    {
                        Objects.Errors.ErrorMessages.Add("An invalid Customer ID has been entered");
                    Objects.Errors.ErrorMessagesFlag = true;
                    frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                    txtID.Text = null;
                    }

                   else {
                             lBoxListResults.Items.Add(findCustomer.CustomerID + ", " + findCustomer.FirstName + ", " + findCustomer.LastName);
                        }

                }
                else
                {
                    Objects.Errors.ErrorMessages.Add("An invalid char has been entered");
                    Objects.Errors.ErrorMessagesFlag = true;
                    frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                    txtID.Text = null;
                    btnSelect.Enabled = false;
                }
            }
            else if (string.IsNullOrWhiteSpace(txtID.Text))
            {
                string name = txtSurname.Text;
                CustomerDBAccess CdbAccess = new CustomerDBAccess(db);
                List<Customer> customers = new List<Customer>();
                customers = CdbAccess.getCustomerBySurname(name);
                for (int i = 0; i < customers.Count; i++){
                    lBoxListResults.Items.Add(customers[i].CustomerID + ", " + customers[i].FirstName + ", " + customers[i].LastName);
                }
            }
                    

            
        }

        private void txtSurname_TextChanged(object sender, EventArgs e){}

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');

                int selectedCusID = Convert.ToInt32(selected[0]);
                CustomerDBAccess cdba = new CustomerDBAccess(db);
                Customer Cust = cdba.getCustomerByID(selectedCusID);
                cboxtitle.Text = Cust.Title;
                txtFirstN.Text = Cust.FirstName;
                txtLastN.Text = Cust.LastName;
                DTPickerDOB.Text = Convert.ToString(Cust.DOB);
                txtAddress.Text = Cust.Address;
                txtContactNo.Text = Cust.ContactNo;
                txtEmail.Text = Cust.Email;
                txtPostCode.Text = Cust.PostCode;
                txtTown.Text = Cust.Town;
                cboxSize.Text = Cust.Size;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message+"Please search for a customer first.");
            }
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            Objects.Errors.ErrorMessagesFlag = false;
            string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
            int selectedCusID = Convert.ToInt32(selected[0]);
            CustomerDBAccess CustUpdate = new CustomerDBAccess(db);
            //validating the new information that has been entered.
            Customer newCust = new Customer();
            newCust.Title = cboxtitle.Text;
            newCust.Address = txtAddress.Text;
            newCust.ContactNo = txtContactNo.Text;
            newCust.Email = txtEmail.Text;
            newCust.FirstName = txtFirstN.Text;
            newCust.LastName = txtLastN.Text;
            newCust.PostCode = txtPostCode.Text;
            newCust.Town = txtTown.Text;
            newCust.DOB = DTPickerDOB.Value;
            newCust.Size = cboxSize.Text;
            
            //if the validation has passed, the customer is updated and the textboxes are blanked.
            if (Objects.Errors.ErrorMessagesFlag == false){
                DBAccess.CustomerDBAccess cus = new DBAccess.CustomerDBAccess(db);
                CustUpdate.UpdateCustomer(selectedCusID, cboxtitle.Text, txtFirstN.Text, txtLastN.Text, txtContactNo.Text, txtAddress.Text, txtTown.Text, txtPostCode.Text, txtEmail.Text, DTPickerDOB.Value, cboxSize.Text);
                MessageBox.Show("Customer has been updated");
                txtAddress.Text = null;
                txtFirstN.Text = null;
                txtLastN.Text = null;
                txtContactNo.Text = null;
                txtEmail.Text = null;
                cboxtitle.Text = null;
                txtTown.Text = null;
                txtPostCode.Text = null;
                DTPickerDOB.Text = null;
                cboxSize.Text = null;
            }
            //if the validation fails then an error message is shown, telling the user which data has been entered incorrectly.
            else if (Objects.Errors.ErrorMessagesFlag == true){
                frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
            }
            
            
        }

      
        private void btnRtrnToMM_Click(object sender, EventArgs e)
        {
            Form1 MM = new Form1(db);
            MM.Show();
            this.Hide();
        }
        
        /* The Grave Yard */  private void lblAddress_Click(object sender, EventArgs e){}private void lblTown_Click(object sender, EventArgs e){}private void lblPostCode_Click(object sender, EventArgs e){}private void lblEmail_Click(object sender, EventArgs e){} private void txtEmail_TextChanged(object sender, EventArgs e){}private void txtPostCode_TextChanged(object sender, EventArgs e){} private void txtTown_TextChanged(object sender, EventArgs e){}private void txtAddress_TextChanged(object sender, EventArgs e){}private void lblCustomerlabel_Click(object sender, EventArgs e){}private void lblIDlabel_Click(object sender, EventArgs e){ } private void txtID_TextChanged(object sender, EventArgs e){}
        
    }
}