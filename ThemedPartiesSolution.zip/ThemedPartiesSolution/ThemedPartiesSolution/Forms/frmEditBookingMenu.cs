﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmEditBookingMenu : Form
    {
        private Database db;
        private int custID;
        private bool edit;
        private int BooID;

        public frmEditBookingMenu(Database db, int custID, bool edit, int BooID)
        {
            InitializeComponent();
            this.db = db;
            this.edit = edit;
            this.custID = custID;
            this.BooID = BooID;
        }

        private void btnDateTime_Click(object sender, EventArgs e)
        {
            frmBooking ED = new frmBooking(db, custID, edit, BooID);
            ED.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BookingDBAccess BDA = new BookingDBAccess(db);
            frmAttendees attend = new frmAttendees(db, BooID, true);
            attend.Show();
        }
    }
}
