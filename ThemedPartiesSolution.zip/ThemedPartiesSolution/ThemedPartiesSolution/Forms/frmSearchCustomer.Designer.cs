﻿namespace ThemedPartiesSolution
{
    partial class frmSearchCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearchCustomer));
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblIDlabel = new System.Windows.Forms.Label();
            this.lblCustomerlabel = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.lbltitle = new System.Windows.Forms.Label();
            this.lBoxListResults = new System.Windows.Forms.ListBox();
            this.btnCreateNewBooking = new System.Windows.Forms.Button();
            this.btnCreateNewCustomer = new System.Windows.Forms.Button();
            this.btnRtrnToMM = new System.Windows.Forms.Button();
            this.btnDeleteCustomer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.DeepPink;
            this.btnSearch.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(284, 138);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(76, 38);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblIDlabel
            // 
            this.lblIDlabel.AutoSize = true;
            this.lblIDlabel.BackColor = System.Drawing.Color.Transparent;
            this.lblIDlabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblIDlabel.Location = new System.Drawing.Point(61, 148);
            this.lblIDlabel.Name = "lblIDlabel";
            this.lblIDlabel.Size = new System.Drawing.Size(28, 19);
            this.lblIDlabel.TabIndex = 3;
            this.lblIDlabel.Text = "ID";
            // 
            // lblCustomerlabel
            // 
            this.lblCustomerlabel.AutoSize = true;
            this.lblCustomerlabel.BackColor = System.Drawing.Color.Transparent;
            this.lblCustomerlabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCustomerlabel.Location = new System.Drawing.Point(32, 100);
            this.lblCustomerlabel.Name = "lblCustomerlabel";
            this.lblCustomerlabel.Size = new System.Drawing.Size(81, 19);
            this.lblCustomerlabel.TabIndex = 2;
            this.lblCustomerlabel.Text = "Surname";
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.Thistle;
            this.txtID.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(112, 148);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(154, 23);
            this.txtID.TabIndex = 1;
            this.txtID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // txtSurname
            // 
            this.txtSurname.BackColor = System.Drawing.Color.Thistle;
            this.txtSurname.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSurname.Location = new System.Drawing.Point(119, 100);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(229, 23);
            this.txtSurname.TabIndex = 0;
            this.txtSurname.TextChanged += new System.EventHandler(this.txtSurname_TextChanged);
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.BackColor = System.Drawing.Color.Transparent;
            this.lbltitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbltitle.Location = new System.Drawing.Point(108, 38);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(184, 25);
            this.lbltitle.TabIndex = 6;
            this.lbltitle.Text = "Search Customer ";
            // 
            // lBoxListResults
            // 
            this.lBoxListResults.BackColor = System.Drawing.Color.Thistle;
            this.lBoxListResults.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBoxListResults.FormattingEnabled = true;
            this.lBoxListResults.ItemHeight = 16;
            this.lBoxListResults.Location = new System.Drawing.Point(47, 204);
            this.lBoxListResults.Name = "lBoxListResults";
            this.lBoxListResults.Size = new System.Drawing.Size(288, 116);
            this.lBoxListResults.TabIndex = 8;
            this.lBoxListResults.SelectedIndexChanged += new System.EventHandler(this.lBoxListResults_SelectedIndexChanged);
            // 
            // btnCreateNewBooking
            // 
            this.btnCreateNewBooking.BackColor = System.Drawing.Color.DeepPink;
            this.btnCreateNewBooking.Enabled = false;
            this.btnCreateNewBooking.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateNewBooking.Location = new System.Drawing.Point(55, 336);
            this.btnCreateNewBooking.Name = "btnCreateNewBooking";
            this.btnCreateNewBooking.Size = new System.Drawing.Size(135, 50);
            this.btnCreateNewBooking.TabIndex = 9;
            this.btnCreateNewBooking.Text = "Create New Booking";
            this.btnCreateNewBooking.UseVisualStyleBackColor = false;
            this.btnCreateNewBooking.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCreateNewCustomer
            // 
            this.btnCreateNewCustomer.BackColor = System.Drawing.Color.DeepPink;
            this.btnCreateNewCustomer.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateNewCustomer.Location = new System.Drawing.Point(196, 336);
            this.btnCreateNewCustomer.Name = "btnCreateNewCustomer";
            this.btnCreateNewCustomer.Size = new System.Drawing.Size(135, 50);
            this.btnCreateNewCustomer.TabIndex = 10;
            this.btnCreateNewCustomer.Text = "Create New Customer";
            this.btnCreateNewCustomer.UseVisualStyleBackColor = false;
            this.btnCreateNewCustomer.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnRtrnToMM
            // 
            this.btnRtrnToMM.BackColor = System.Drawing.Color.DeepPink;
            this.btnRtrnToMM.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRtrnToMM.Location = new System.Drawing.Point(196, 392);
            this.btnRtrnToMM.Name = "btnRtrnToMM";
            this.btnRtrnToMM.Size = new System.Drawing.Size(135, 50);
            this.btnRtrnToMM.TabIndex = 12;
            this.btnRtrnToMM.Text = "Return to Main Menu";
            this.btnRtrnToMM.UseVisualStyleBackColor = false;
            this.btnRtrnToMM.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnDeleteCustomer
            // 
            this.btnDeleteCustomer.BackColor = System.Drawing.Color.DeepPink;
            this.btnDeleteCustomer.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteCustomer.Location = new System.Drawing.Point(55, 392);
            this.btnDeleteCustomer.Name = "btnDeleteCustomer";
            this.btnDeleteCustomer.Size = new System.Drawing.Size(135, 50);
            this.btnDeleteCustomer.TabIndex = 13;
            this.btnDeleteCustomer.Text = "Delete Customer";
            this.btnDeleteCustomer.UseVisualStyleBackColor = false;
            this.btnDeleteCustomer.Click += new System.EventHandler(this.btnDeleteCustomer_Click);
            // 
            // frmSearchCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(388, 465);
            this.Controls.Add(this.btnDeleteCustomer);
            this.Controls.Add(this.btnRtrnToMM);
            this.Controls.Add(this.btnCreateNewCustomer);
            this.Controls.Add(this.btnCreateNewBooking);
            this.Controls.Add(this.lBoxListResults);
            this.Controls.Add(this.lbltitle);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblIDlabel);
            this.Controls.Add(this.lblCustomerlabel);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.txtID);
            this.Name = "frmSearchCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Customer";
            this.Load += new System.EventHandler(this.frmSearchCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblIDlabel;
        private System.Windows.Forms.Label lblCustomerlabel;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.ListBox lBoxListResults;
        private System.Windows.Forms.Button btnCreateNewBooking;
        private System.Windows.Forms.Button btnCreateNewCustomer;
        private System.Windows.Forms.Button btnRtrnToMM;
        private System.Windows.Forms.Button btnDeleteCustomer;
    }
}