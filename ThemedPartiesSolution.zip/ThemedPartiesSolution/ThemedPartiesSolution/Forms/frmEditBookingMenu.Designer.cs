﻿namespace ThemedPartiesSolution.Forms
{
    partial class frmEditBookingMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDateTime = new System.Windows.Forms.Button();
            this.btnEditAttendees = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDateTime
            // 
            this.btnDateTime.BackColor = System.Drawing.Color.DeepPink;
            this.btnDateTime.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.btnDateTime.Location = new System.Drawing.Point(91, 98);
            this.btnDateTime.Name = "btnDateTime";
            this.btnDateTime.Size = new System.Drawing.Size(126, 42);
            this.btnDateTime.TabIndex = 0;
            this.btnDateTime.Text = "Date / Time";
            this.btnDateTime.UseVisualStyleBackColor = false;
            this.btnDateTime.Click += new System.EventHandler(this.btnDateTime_Click);
            // 
            // btnEditAttendees
            // 
            this.btnEditAttendees.BackColor = System.Drawing.Color.DeepPink;
            this.btnEditAttendees.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.btnEditAttendees.Location = new System.Drawing.Point(91, 159);
            this.btnEditAttendees.Name = "btnEditAttendees";
            this.btnEditAttendees.Size = new System.Drawing.Size(126, 42);
            this.btnEditAttendees.TabIndex = 1;
            this.btnEditAttendees.Text = "Attendees / Costumes";
            this.btnEditAttendees.UseVisualStyleBackColor = false;
            this.btnEditAttendees.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTitle.Location = new System.Drawing.Point(33, 52);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(243, 19);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "What would you like to Edit?";
            // 
            // frmEditBookingMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ThemedPartiesSolution.Properties.Resources.Untitled_3;
            this.ClientSize = new System.Drawing.Size(310, 235);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnEditAttendees);
            this.Controls.Add(this.btnDateTime);
            this.Name = "frmEditBookingMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Booking Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDateTime;
        private System.Windows.Forms.Button btnEditAttendees;
        private System.Windows.Forms.Label lblTitle;
    }
}