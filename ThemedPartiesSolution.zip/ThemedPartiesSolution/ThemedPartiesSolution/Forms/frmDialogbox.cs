﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmDialogbox : Form
    {

        private int ID;
        private Database DB;

        public frmDialogbox(Database DB, int ID)
        {
            InitializeComponent();
            this.ID = ID;
            this.DB = DB;
        }

        private void Dialogbox_Load(object sender, EventArgs e)
        {
            lblDialogText.Text = Errors.DialogResultText;
            if (Errors.DialogResultText[0] != 'Y')
            {
                btnCancel.Visible = false;
                btnOkay.Visible = false;
                lblContinue2.Visible = false;
                btnClose.Visible = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmSearchCustomer Search = new frmSearchCustomer(DB);
            Search.Show();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            bool edit = false;
            int BooID = 0;
            frmBooking Booking = new frmBooking(DB,ID, edit, BooID);
            Booking.Show();
            this.Hide();
        }

        private void lblDialogText_Click(object sender, EventArgs e){}

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
