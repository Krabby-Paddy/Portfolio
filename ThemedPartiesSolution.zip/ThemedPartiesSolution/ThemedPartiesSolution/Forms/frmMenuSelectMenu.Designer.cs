﻿namespace ThemedPartiesSolution.Forms
{
    partial class frmMenuSelectMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenuSelectMenu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblEventsUnlimited = new System.Windows.Forms.Label();
            this.btnCatering = new System.Windows.Forms.Button();
            this.btnWedding = new System.Windows.Forms.Button();
            this.btnThemedP = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::ThemedPartiesSolution.Properties.Resources.actuallogo;
            this.pictureBox1.Location = new System.Drawing.Point(230, 55);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblEventsUnlimited
            // 
            this.lblEventsUnlimited.AutoSize = true;
            this.lblEventsUnlimited.BackColor = System.Drawing.Color.Transparent;
            this.lblEventsUnlimited.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEventsUnlimited.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblEventsUnlimited.Location = new System.Drawing.Point(175, 201);
            this.lblEventsUnlimited.Name = "lblEventsUnlimited";
            this.lblEventsUnlimited.Size = new System.Drawing.Size(271, 37);
            this.lblEventsUnlimited.TabIndex = 1;
            this.lblEventsUnlimited.Text = "Events Unlimited";
            // 
            // btnCatering
            // 
            this.btnCatering.BackColor = System.Drawing.Color.DeepPink;
            this.btnCatering.Enabled = false;
            this.btnCatering.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.btnCatering.Location = new System.Drawing.Point(230, 261);
            this.btnCatering.Name = "btnCatering";
            this.btnCatering.Size = new System.Drawing.Size(165, 44);
            this.btnCatering.TabIndex = 2;
            this.btnCatering.Text = "Catering";
            this.btnCatering.UseVisualStyleBackColor = false;
            // 
            // btnWedding
            // 
            this.btnWedding.BackColor = System.Drawing.Color.DeepPink;
            this.btnWedding.Enabled = false;
            this.btnWedding.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.btnWedding.Location = new System.Drawing.Point(230, 361);
            this.btnWedding.Name = "btnWedding";
            this.btnWedding.Size = new System.Drawing.Size(165, 44);
            this.btnWedding.TabIndex = 3;
            this.btnWedding.Text = "Weddings";
            this.btnWedding.UseVisualStyleBackColor = false;
            // 
            // btnThemedP
            // 
            this.btnThemedP.BackColor = System.Drawing.Color.DeepPink;
            this.btnThemedP.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.btnThemedP.Location = new System.Drawing.Point(230, 311);
            this.btnThemedP.Name = "btnThemedP";
            this.btnThemedP.Size = new System.Drawing.Size(165, 44);
            this.btnThemedP.TabIndex = 4;
            this.btnThemedP.Text = "Themed Parties";
            this.btnThemedP.UseVisualStyleBackColor = false;
            this.btnThemedP.Click += new System.EventHandler(this.btnThemedP_Click);
            // 
            // frmMenuSelectMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ThemedPartiesSolution.Properties.Resources.Untitled_3;
            this.ClientSize = new System.Drawing.Size(632, 416);
            this.Controls.Add(this.btnThemedP);
            this.Controls.Add(this.btnWedding);
            this.Controls.Add(this.btnCatering);
            this.Controls.Add(this.lblEventsUnlimited);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmMenuSelectMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Select Menu";
            this.Load += new System.EventHandler(this.frmMenuSelectMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblEventsUnlimited;
        private System.Windows.Forms.Button btnCatering;
        private System.Windows.Forms.Button btnWedding;
        private System.Windows.Forms.Button btnThemedP;
    }
}