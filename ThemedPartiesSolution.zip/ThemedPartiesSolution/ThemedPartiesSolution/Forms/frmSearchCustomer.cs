﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution
{
    public partial class frmSearchCustomer : Form
    {

        private Database db;
        private DataTable table;

        public frmSearchCustomer(Database db){
            InitializeComponent();
            this.db = db;
        }

        private void btnSearch_Click(object sender, EventArgs e){
            btnCreateNewBooking.Enabled = true;
            lBoxListResults.Items.Clear();
            if (string.IsNullOrWhiteSpace(txtSurname.Text)){
                string TempID = txtID.Text;
                bool flag = true;
                for (int i = 0; i > TempID.Length; i++){
                    if (!char.IsDigit(TempID[i])){
                        flag = false;   
                    }
                 
                }
                try
                    {

                    if (flag == true){
                    
                                        int id = Convert.ToInt32(txtID.Text);
                                    List<Customer> customer = new List<Customer>();
                                    Customer findCustomer = new Customer();
                                    CustomerDBAccess CdbAccess = new CustomerDBAccess(db);
                                    findCustomer = CdbAccess.getCustomerByID(id);
                                    customer.Add(findCustomer);
                        if(findCustomer.FirstName == null)
                        {
                                        Objects.Errors.ErrorMessages.Add("An invalid customerID has been entered");
                                        Objects.Errors.ErrorMessagesFlag = true;
                                        frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                                        txtID.Text = null;
                        }
                        else 
                        {
                            CreateTableResults(customer);
                            lBoxListResults.Items.Add(findCustomer.CustomerID + ", " + findCustomer.FirstName + " " + findCustomer.LastName + ", " + findCustomer.PostCode);    
                        }
                                    
                
                                    }
                                    else
                                    {
                                        
                                    }
                                }
                catch (Exception)
                {
                    Objects.Errors.ErrorMessages.Add("Please Enter and Search For a Customer.");
                    Objects.Errors.ErrorMessagesFlag = true;
                    frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                }
                    }

            else if (string.IsNullOrWhiteSpace(txtID.Text)){
                string name = txtSurname.Text;
                CustomerDBAccess CdbAccess = new CustomerDBAccess(db);
                List<Customer> customers = new List<Customer>();
                customers = CdbAccess.getCustomerBySurname(name);
                for(int i = 0; i<customers.Count; i++){
                    lBoxListResults.Items.Add(customers[i].CustomerID + ", " + customers[i].FirstName + " " + customers[i].LastName + ", " + customers[i].PostCode);    
                }
            }
        }

        private void CreateTableResults(List<Customer> list){   
            table = new DataTable();
            table.Columns.Add("Customer ID");
            table.Columns.Add("Title");
            table.Columns.Add("First Name");
            table.Columns.Add("Last Name");
            table.Columns.Add("Contact Number");
            table.Columns.Add("Address");
            table.Columns.Add("Town");
            table.Columns.Add("PostCode");
            table.Columns.Add("E-mail");
            table.Columns.Add("Date of Birth");

            foreach (Customer customer in list){
                table.Rows.Add(customer.CustomerID, customer.Title, customer.FirstName, customer.LastName, customer.ContactNo, customer.Address, customer.Town, customer.PostCode, customer.Email);
            } 

        }


                private void button1_Click(object sender, EventArgs e){

                    try {string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
                    Errors.DialogResultText = "You have selected" + selected[1] + " " + selected[2] + ",";
                    int CusID = Convert.ToInt32(selected[0]);
                    frmDialogbox DB = new frmDialogbox(db, CusID);
                    DB.Show();
                    this.Hide();
                    }
                    catch (Exception) 
                    { 
                        Objects.Errors.ErrorMessages.Add("Please Search for and Select a Customer.");
                        Objects.Errors.ErrorMessagesFlag = true;

                        frmErrors ErrorMessages = new frmErrors(); 
                        ErrorMessages.Show(); 
                    }
                }

                private void button2_Click(object sender, EventArgs e){
                    frmAddCustomer Addcust = new frmAddCustomer(db);
                    this.Hide();
                    Addcust.Show();
                }

    private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e){}
        private void txtSurname_TextChanged(object sender, EventArgs e){}
            private void frmSearchCustomer_Load(object sender, EventArgs e){} 
                private void txtID_TextChanged(object sender, EventArgs e){} 
                    private void EditCus(){}

                    private void button4_Click(object sender, EventArgs e)
                    {
                        Form1 mm = new Form1(db);
                        mm.Show();
                        this.Hide();
                    }

                    private void button3_Click(object sender, EventArgs e)
                    {

                    }

                    private void btnDeleteCustomer_Click(object sender, EventArgs e)
                    {
                        try
                        {
                            string[] selected = lBoxListResults.SelectedItem.ToString().Split(',');
                            int CusID = Convert.ToInt32(selected[0]);
                            CustomerDBAccess cdba = new CustomerDBAccess(db);
                            cdba.DeleteCust(CusID);
                        }
                        catch (Exception)
                        {
                            Objects.Errors.ErrorMessages.Add("Please Select a Customer to delete.");
                            Objects.Errors.ErrorMessagesFlag = true;

                            frmErrors ErrorMessages = new frmErrors();
                            ErrorMessages.Show(); 
            
         
        }
                    }

        private void lBoxListResults_SelectedIndexChanged(object sender, EventArgs e){}
    }
}