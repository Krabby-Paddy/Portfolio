﻿namespace ThemedPartiesSolution.Forms
{
    partial class frmDialogbox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDialogText = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOkay = new System.Windows.Forms.Button();
            this.lblContinue2 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDialogText
            // 
            this.lblDialogText.AutoSize = true;
            this.lblDialogText.BackColor = System.Drawing.Color.Transparent;
            this.lblDialogText.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDialogText.Location = new System.Drawing.Point(22, 27);
            this.lblDialogText.Name = "lblDialogText";
            this.lblDialogText.Size = new System.Drawing.Size(35, 13);
            this.lblDialogText.TabIndex = 0;
            this.lblDialogText.Text = "label1";
            this.lblDialogText.Click += new System.EventHandler(this.lblDialogText_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DeepPink;
            this.btnCancel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCancel.Location = new System.Drawing.Point(39, 81);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "No";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOkay
            // 
            this.btnOkay.BackColor = System.Drawing.Color.DeepPink;
            this.btnOkay.Location = new System.Drawing.Point(140, 81);
            this.btnOkay.Name = "btnOkay";
            this.btnOkay.Size = new System.Drawing.Size(75, 23);
            this.btnOkay.TabIndex = 2;
            this.btnOkay.Text = "Yes";
            this.btnOkay.UseVisualStyleBackColor = false;
            this.btnOkay.Click += new System.EventHandler(this.btnOkay_Click);
            // 
            // lblContinue2
            // 
            this.lblContinue2.AutoSize = true;
            this.lblContinue2.BackColor = System.Drawing.Color.Transparent;
            this.lblContinue2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblContinue2.Location = new System.Drawing.Point(52, 54);
            this.lblContinue2.Name = "lblContinue2";
            this.lblContinue2.Size = new System.Drawing.Size(139, 13);
            this.lblContinue2.TabIndex = 3;
            this.lblContinue2.Text = "Would you like to continue?";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.DeepPink;
            this.btnClose.Location = new System.Drawing.Point(89, 81);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Visible = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmDialogbox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ThemedPartiesSolution.Properties.Resources.Untitled_3;
            this.ClientSize = new System.Drawing.Size(257, 116);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblContinue2);
            this.Controls.Add(this.btnOkay);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblDialogText);
            this.Name = "frmDialogbox";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dialogbox";
            this.Load += new System.EventHandler(this.Dialogbox_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDialogText;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOkay;
        private System.Windows.Forms.Label lblContinue2;
        private System.Windows.Forms.Button btnClose;
    }
}