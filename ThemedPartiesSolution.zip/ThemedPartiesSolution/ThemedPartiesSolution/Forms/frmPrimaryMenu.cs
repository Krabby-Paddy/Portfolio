﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.Forms
{
    public partial class frmPrimaryMenu : Form
    {

        private Database db;
        public frmPrimaryMenu(Database db)
        {
            InitializeComponent();
            this.db = db;
        }

        private void btnAddCus_Click(object sender, EventArgs e)
        {
            Form1 mm = new Form1(db);
            mm.Show();
            this.Hide();
        }

        private void btnBooMenu_Click(object sender, EventArgs e)
        {
            frmBookingMenu bm = new frmBookingMenu(db);
            bm.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            frmMenuSelectMenu msm = new frmMenuSelectMenu(db);
            msm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmReport report = new frmReport();
            report.Show();

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDialogExit DE = new frmDialogExit();
            DE.Show();
        }

        private void frmPrimaryMenu_Load(object sender, EventArgs e)
        {
        
}
    }
}
