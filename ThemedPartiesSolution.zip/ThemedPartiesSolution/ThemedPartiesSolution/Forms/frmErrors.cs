﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution
{
    public partial class frmErrors : Form
    {
        public frmErrors()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void frmErrors_Load(object sender, EventArgs e)
        {
            if (Objects.Errors.ErrorMessages.Count == 1)
            {
                groupBox1.Text = "The following error has occured: ";
            }
            else { groupBox1.Text = "The following errors have occured: "; }  

             lblError.Text = string.Join(Environment.NewLine,Objects.Errors.ErrorMessages);
             Objects.Errors.ErrorMessages.Clear();
             Objects.Errors.ErrorMessagesFlag = false;
        }

        private void btnCloseErrorForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}