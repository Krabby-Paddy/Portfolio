﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;
using ThemedPartiesSolution.Forms;

namespace ThemedPartiesSolution
{
    public partial class frmBooking : Form
    {
        private Database db;
        private int ID;
        private int timeOfEvent = 0;
        private bool edit;
        private int booID;

        public frmBooking(Database db, int ID, bool edit, int booID)
        {
            this.edit = edit;
            this.db = db;
            this.ID = ID;
            this.booID = booID;
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e){}

        private void frmBooking_Load(object sender, EventArgs e)
        {
            if(edit == true)//set the form up for edit mode
            {
                btnCreateBooking.Text = "Save Changes";
                btnAddAtt.Text = "Edit Attendees";
                lblFormtitle.Text = "Edit Booking";
                BookingDBAccess BDBA = new BookingDBAccess(db);
                Booking selectedbooking = BDBA.getBookingByID(booID);
                dtpDOE.Value = Convert.ToDateTime(selectedbooking.DateAndTimeOfEvent);
                if (selectedbooking.Theme == "MurderM")
                {
                    chkBmurderM.Checked = true;
                }
                else { checkBox1.Checked = true; }
                if (selectedbooking.TimeOfEvent == 1)
                {
                    chBox6pm.Checked = true;
                }
                else
                {
                    chBox9pm.Checked = true;
                }
            }
            btnAddAtt.Enabled = false; //disabling the add attendees button
            lblDOB.Text = Convert.ToString(System.DateTime.Now); //automatically showing todays date as date of booking
            CustomerDBAccess cdba = new CustomerDBAccess(db);
            Customer Cust = cdba.getCustomerByID(ID); //getting the customer object related to the ID used in the booking
            //automatically showing all of the customers details on the form
            lblCusTitle.Text = Cust.Title;
            lblCusFirstName.Text = Cust.FirstName;
            lblCusSecondName.Text = Cust.LastName;
            lblCusDOB.Text = Convert.ToString(Cust.DOB);
            lblCusAddress.Text = Cust.Address;
            lblCusContactNo.Text = Cust.ContactNo;
            lblCusEmailAddress.Text = Cust.Email;
            lblCusPostCode.Text = Cust.PostCode;
            lblCusTown.Text = Cust.Town;
            
        }

        private void lblDaToE_Click(object sender, EventArgs e){}

        private void btnCreateAtt_Click(object sender, EventArgs e)
        {
            btnCreateBooking.Enabled = false;
            Objects.Errors.ErrorMessagesFlag = false; //resetting the error message flag
            Booking newBoo = new Booking(); //creating a new booking object
            newBoo.DateAndTimeOfEvent = dtpDOE.Value; //setting the selected date of event
            newBoo.DateOfBooking = DateTime.Today; //automatically setting the date of booking
            if (chBox6pm.Checked == false && chBox9pm.Checked == false || chkBmurderM.Checked == false && checkBox1.Checked == false) // If a time slot hasn't been chosen
            {
                MessageBox.Show("Please select a time slot and theme for the event."); //Display and Message and do nothing 
            }
            else //If one has been selected then contine with other validation
            {
                if (chBox6pm.Checked == true)
                {
                    newBoo.TimeOfEvent = 1; //set event time to 6pm
                    
                }
                else if (chBox9pm.Checked == true)
                {
                    newBoo.TimeOfEvent = 2; //set event time to 9pm
                }
                if (chkBmurderM.Checked == true)
                {
                    newBoo.Theme = "MurderM"; //set event theme to Murder Mystery
                }
                else if (checkBox1.Checked == true)
                {
                    newBoo.Theme = "Bday"; //set event theme to birthday (button is diabled>>this should not be selected)
                }
                if (Objects.Errors.ErrorMessagesFlag == false)
                {
                    BookingDBAccess bdba = new BookingDBAccess(db);
                    Booking Nbook = bdba.checkDoubleBooking(ID, newBoo.DateAndTimeOfEvent);
                    Console.WriteLine(Nbook.CustomerID);
                    if (Nbook.CustomerID == ID)
                    {
                        btnCreateBooking.Enabled = true;
                        Objects.Errors.ErrorMessagesFlag = true; //error flag set to true.
                        Objects.Errors.ErrorMessages.Add("Sorry, you already have a booking on this date."); //display an erorr message telling the user that this booking has already been made
                        frmErrors errormessages = new frmErrors(); 
                        errormessages.Show(); //show the error message form
                        Objects.Errors.ErrorMessages.Clear(); //clear error message list
                    }
                    else
                    {
                        if (edit == true)
                        {
                            BookingDBAccess bdba1 = new BookingDBAccess(db);
                            bdba1.UpdateBooking(booID, newBoo.DateAndTimeOfEvent, newBoo.DateOfBooking, newBoo.TimeOfEvent, newBoo.Theme, ID);
                            Errors.DialogResultText = "Booking Updated!"; //display a message telling the user that the creation of their booking was successful
                            int Temp = 0;
                            frmDialogbox Dialog = new frmDialogbox(db, Temp);
                            Dialog.Show();
                        }
                        else
                        {
                            BookingDBAccess Boo = new BookingDBAccess(db);
                            Boo.InsertBooking(newBoo.DateAndTimeOfEvent, newBoo.DateOfBooking, newBoo.TimeOfEvent, newBoo.Theme, ID);
                            Errors.DialogResultText = "New Booking Added!"; //display a message telling the user that the creation of their booking was successful
                            int Temp = 0;
                            frmDialogbox Dialog = new frmDialogbox(db, Temp);
                            Dialog.Show();
                        }

                    dtpDOE = null; //reset all inputs on form
                    chkBmurderM.Checked = false; chkBmurderM.Enabled = false;
                    checkBox1.Checked = false; checkBox1.Enabled = false;
                    chBox6pm.Checked = false; chBox6pm.Enabled = false;
                    chBox9pm.Checked = false; chBox9pm.Enabled = false;
                  //  dtpDOE.Enabled = false;
                    
                    btnAddAtt.Enabled = true; //Enable Add Attendee button

                    }
                }
                else
                {
                    //if the booking cannot be created, show the Error message form telling the user why.
                    frmErrors ErrorMessages = new frmErrors(); ErrorMessages.Show();
                }
            }
        }
               
        //preventing both checkboxes from being checked at once
        private void chBox6pm_CheckedChanged(object sender, EventArgs e)
        {
            chBox9pm.Checked = false;
        }

        private void chBox9pm_CheckedChanged(object sender, EventArgs e)
        {
            chBox6pm.Checked = false;
        }

        //preventing both theme types from being selected at once
        private void chkBmurderM_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            chkBmurderM.Checked = false;
        }

        private void btnAddAtt_Click(object sender, EventArgs e) //button to open the "Add Attendees" form 
        {
            if (edit == false)
            {
            BookingDBAccess BDA = new BookingDBAccess(db);
                        frmAttendees attend = new frmAttendees(db, BDA.getLatestBookingID(), false);
                        attend.Show();
            }
            else
            {
                BookingDBAccess BDA = new BookingDBAccess(db);
                frmAttendees attend = new frmAttendees(db, BDA.getLatestBookingID(), true);
                attend.Show();
            }

            this.Hide(); //close the current form after frmAttendees has been opened

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 MM = new Form1(db);
            this.Hide();
            MM.Show();
        }        
     }
  }