﻿namespace ThemedPartiesSolution {
    
    
    public partial class database1DataSet1 {
        partial class DataTable1DataTable
        {
        }
    }
}
