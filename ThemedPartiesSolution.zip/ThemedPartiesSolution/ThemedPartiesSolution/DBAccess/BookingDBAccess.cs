﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.DBAccess
{
    class BookingDBAccess
    {
        private Database db;
       //private int custID;
        public BookingDBAccess(Database db)
        {
            this.db = db;
            //this.custID = custID;
        }

        public void InsertBooking(DateTime DateAndTimeOfEvent, DateTime DateOfBooking, int TimeOfEvent, string Theme, int custID)
        {
            string SqlDateOfBooking = DateOfBooking.ToString("yyyy-MM-dd hh:mm:ss.fff");
            string SqlDateOfEvent = DateAndTimeOfEvent.ToString("yyyy-MM-dd hh:mm:ss.fff");
            //SqlDateOfEvent = SqlDateOfEvent.
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO BookingTBL (DateOfBooking, DateAndTimeOfEvent, TimeOfEvent, Theme, CustomerID)" + "VALUES ('" + SqlDateOfBooking + "', '" + SqlDateOfEvent + "', '" + TimeOfEvent + "', '" + Theme + "','" + custID + "')";
            db.Cmd.ExecuteNonQuery();
        }

        public int getLatestBookingID()
        {
            int id = 0;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT TOP 1 * FROM BookingTBL ORDER BY BookingID DESC";
            db.Rdr = db.Cmd.ExecuteReader();
            while(db.Rdr.Read())
            {
                id = getBookingID(db.Rdr);
            }
            db.Rdr.Close();
            return id;
        }

        public int getBookingID(SqlDataReader reader)
        {
            int ID = reader.GetInt32(0);
            return ID;
        }

        public Booking getBookingByID(int ID)
        {
            Booking result = new Booking();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM BookingTBL WHERE BookingID =" + ID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
                {
                    result = getBookingFromReader(db.Rdr);
                }
            db.Rdr.Close();
            return result;
        }

        public List<Booking> getBookingByCustID(int ID)
        {
            List<Booking> results = new List<Booking>();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM BookingTBL WHERE CustomerID =" + ID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                results.Add(getBookingFromReader(db.Rdr));
            }
            db.Rdr.Close(); 
            return results;
        }

        public Booking getBookingByDate(DateTime Date)
        {
            string date = Date.ToString("yyyy-MM-dd hh:mm:ss.fff");
            Booking result = new Booking();
                db.Cmd = db.Conn.CreateCommand();
                db.Cmd.CommandText = "SELECT * FROM BookingTBL WHERE DateAndTimeOfEvent =" + date;
                db.Rdr = db.Cmd.ExecuteReader();
                while (db.Rdr.Read())
                {
                    result = getBookingFromReader(db.Rdr);
                }
                db.Rdr.Close(); return result;
            }

       public Booking checkDoubleBooking(int ID, DateTime Date) //checking for double-booking
        {
            string date = Date.ToString("yyyy-MM-dd hh:mm:ss.fff");
            Booking TempBooking = new Booking();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM BookingTBL WHERE CustomerID =" + ID + " AND DateAndTimeOfEvent='" + date + "'";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                TempBooking = getBookingFromReader(db.Rdr);
            }
            db.Rdr.Close();
            return TempBooking;
        }
        
        public Booking getBookingFromReader(SqlDataReader reader)
        {
            //get booking from reader using Access Method and create an object using the details gathered.
            Booking newBooking    = new Booking();
            newBooking.BookingID = reader.GetInt32(0);
            newBooking.DateOfBooking = reader.GetDateTime(1);
            newBooking.DateAndTimeOfEvent = reader.GetDateTime(2);
            newBooking.TimeOfEvent = reader.GetInt32(3);
            newBooking.Theme = reader.GetString(4);
            newBooking.CustomerID = reader.GetInt32(5);
            return newBooking;
        }

        public void DeleteBookng(int id)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "DELETE FROM BookingTBL WHERE BookingID = " + id;
            db.Cmd.ExecuteNonQuery();
        }

        public void UpdateBooking(int bookingID, DateTime DateAndTimeOfEvent, DateTime DateOfBooking, int TimeOfEvent, string Theme, int custID)
        {
            string SqlDateOfBooking = DateOfBooking.ToString("yyyy-MM-dd hh:mm:ss.fff");
            string SqlDateOfEvent = DateAndTimeOfEvent.ToString("yyyy-MM-dd hh:mm:ss.fff");
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "UPDATE BookingTBL SET DateOfBooking ='" + SqlDateOfBooking + "', DateAndTimeOfEvent = '" + SqlDateOfEvent + "', TimeOfEvent = " + TimeOfEvent + ", Theme = '" + Theme + "', CustomerID = " + custID + "WHERE BookingID = " + bookingID;
            db.Cmd.ExecuteNonQuery();
        }


        }
}