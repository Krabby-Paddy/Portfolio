﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.DBAccess
{

    public class AttendeeDBAccess
    {
        private Database db;

        public AttendeeDBAccess(Database db)
        {
            this.db = db;
        }

        public List<int> getCostumeIDByBookingID(int bookingID)
        {
            List<int> result = new List<int>();
            int found;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT CostumeID FROM AttendeesTBL WHERE BookingID  =" + bookingID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getCostumeID(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;
        }

        public int getAttendID(int bookingID, int customerID)
        {
            
            int found;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT AttendeesID FROM AttendeesTBL WHERE BookingID  =" + bookingID+" AND CustomerID ="+customerID;
            db.Rdr = db.Cmd.ExecuteReader();
            found = getAttendeeID(db.Rdr);
            db.Rdr.Close();
            return found;
        }


        public List<int> getAttendeesByBookingID(int bookingID)
        {
            List<int> result = new List<int>();
            int found;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT AttendeesID FROM AttendeesTBL WHERE BookingID  =" + bookingID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getAttendeeID(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;
        }

        public List<Attendees> getAllAttendeesByBookingID(int bookingID)
        {
            List<Attendees> result = new List<Attendees>();
            Attendees found;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM AttendeesTBL WHERE BookingID ="+bookingID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getAttendeeFromReader(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;
        }

        public Attendees getAttendeeFromReader(SqlDataReader reader)
        {
            Attendees attend = new Attendees();
            attend.AttendeesID = reader.GetInt32(0);
            attend.BookingID = reader.GetInt32(1);
            attend.CustomerID = reader.GetInt32(2);
            attend.CostumeID = reader.GetInt32(3);
            return attend;
        }

        public int getAttendeeID(SqlDataReader reader)
        {
            return reader.GetInt32(0);
        }

        public List<string> getSelectedRoles(int BookingID)
        {
            List<string> result = new List<string>();
            string found;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT Role FROM CostumeTBL INNERJOIN AttendeeTBL ON CostumeTBL.CostumeID = AttendeeTBL.CostumeID WHERE AttendeeTBL.EventID ="+BookingID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getRoleFromReader(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;
        }

        public string getRoleFromReader(SqlDataReader reader)
        {
            return reader.GetString(0);
        }

        public int getCostumeID(SqlDataReader reader)
        {
            return reader.GetInt32(0);
        }

        public void addAttendee(int bookingID, int customerID)
        {
            int CostumeID = 1;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO AttendeesTBL(BookingID, CustomerID, CostumeID)" + "VALUES(" + bookingID + ", " + customerID + "," + CostumeID + ")";
            db.Cmd.ExecuteNonQuery();
        }

        public void removeAttendee(int customerID)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "DELETE FROM AttendeesTBL WHERE CustomerID = " + customerID;
            db.Cmd.ExecuteNonQuery();
        }

        public void UpdateAttendee(int attendeeID, int CostID)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "UPDATE AttendeesTBL SET CostumeID =" + CostID + " WHERE AttendeesID = " + attendeeID; ;
            db.Cmd.ExecuteNonQuery();
        }
    }
}