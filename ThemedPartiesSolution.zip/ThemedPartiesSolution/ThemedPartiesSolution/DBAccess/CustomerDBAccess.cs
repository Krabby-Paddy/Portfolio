﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ThemedPartiesSolution.Objects;

namespace ThemedPartiesSolution.DBAccess
{
    class CustomerDBAccess
    {
        private Database db;

        public CustomerDBAccess(Database db)
        {
            this.db = db;
        }

        public List<Customer> wildCardSearch(string customerLastName, int bookingid, string Date)
        {
            List<Customer> result = new List<Customer>();
            Customer found = new Customer();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM CustomerTBL WHERE LastName LIKE '"+customerLastName+"%' AND CustomerID NOT IN(SELECT CustomerID FROM AttendeesTBL WHERE BookingID ="+ bookingid+") AND CustomerID NOT IN(SELECT CustomerID From BookingTBL WHERE DateAndTimeOfEvent = '" + Date +"')";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getCustomersFromReader(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;
        }

        public List<Customer> getAttendees(int bookingid)
        {
            List<Customer> result = new List<Customer>();
            Customer found = new Customer();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM CustomerTBL WHERE CustomerID IN(SELECT CustomerID FROM AttendeesTBL WHERE BookingID =" + bookingid + ")";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getCustomersFromReader(db.Rdr);
                result.Add(found);
            }
            db.Rdr.Close();
            return result;

        }

        public void InsertCustomer(String Title, String firstName, String LastName, String contactNo, String address, String town, String postCode, String email, DateTime dob, String size)
        {
            string sqlDate = dob.ToString("yyyy-MM-dd hh:mm:ss.fff");
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO CustomerTBL (Title, FirstName, LastName, ContactNo, Address, Town, PostCode, Email, DOB, Size)" + "VALUES ('" + Title + "', '" + firstName + "', '" + LastName + "', '" + contactNo + "', '" + address + "', '" + town + "', '" + postCode + "', '" + email + "','" + sqlDate + "','" + size + "')";
             db.Cmd.ExecuteNonQuery();
        }

        public void UpdateCustomer(int CustomerID, String title, String firstName, String lastName, String contactNo, String address, String town, String postCode, String email, DateTime dob, String size)
        {
            string sqlDate = dob.ToString("yyyy-MM-dd hh:mm:ss.fff");
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "UPDATE CustomerTBL SET Title ='" + title + "', FirstName = '" + firstName + "', LastName = '" + lastName + "', ContactNo = '" + contactNo + "', Address = '" + address + "', Town = '" + town + "', PostCode = '" + postCode + "', Email = '" + email + "', DOB = '" + sqlDate + "', Size = '" + size + "' WHERE CustomerID = " + CustomerID; ;
            db.Cmd.ExecuteNonQuery();
        }

        public List<Customer> getAllCustomers()
        {
            List<Customer> results = new List<Customer>();
            db.Cmd = db.Conn.CreateCommand();   
            db.Cmd.CommandText = "SELECT * FROM CustomerTBL";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                //results.Add(getCustomersFromReader(db.Rdr));
            }
            db.Rdr.Close();
            return results;
        }
        
   public Customer getCustomersFromReader(SqlDataReader reader)
   {
       Customer newCustomer    = new Customer();
        newCustomer.CustomerID = reader.GetInt32(0);
        newCustomer.Title      = reader.GetString(1);
        newCustomer.FirstName  = reader.GetString(2);
        newCustomer.LastName   = reader.GetString(3);
        newCustomer.ContactNo  = reader.GetString(4);
        newCustomer.Address    = reader.GetString(5);
        newCustomer.Town       = reader.GetString(6);
        newCustomer.PostCode   = reader.GetString(7);
        newCustomer.Email      = reader.GetString(8);
        newCustomer.DOB        = reader.GetDateTime(9);
        newCustomer.Size       = reader.GetString(10);
        return newCustomer;
    }

   public List<Customer> getCustomerBySurname(string customerLastName)
   {
       List<Customer> result = new List<Customer>();
       Customer found = new Customer();
       db.Cmd = db.Conn.CreateCommand();
       db.Cmd.CommandText = "SELECT * FROM CustomerTBL WHERE LastName ='" + customerLastName+"'";
       db.Rdr = db.Cmd.ExecuteReader();
       while (db.Rdr.Read())
       {
           found = getCustomersFromReader(db.Rdr);
           result.Add(found);
       }
       db.Rdr.Close();
       return result;
   }

        public Customer getCustomerByID(int customerID)
   {
       Customer result = new Customer();
       db.Cmd = db.Conn.CreateCommand();
       db.Cmd.CommandText = "SELECT * FROM CustomerTBL WHERE CustomerID =" + customerID;
       db.Rdr = db.Cmd.ExecuteReader();
       while (db.Rdr.Read())
       {
           result = getCustomersFromReader(db.Rdr);
       }
       db.Rdr.Close();
       return result;
      }

        public void DeleteCust(int customerID)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "DELETE FROM CustomerTBL WHERE CustomerID = " + customerID;
            db.Cmd.ExecuteNonQuery();
        }
    }
}