﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThemedPartiesSolution.DBAccess;
using ThemedPartiesSolution.Objects;
using System.Data.SqlClient;

namespace ThemedPartiesSolution.DBAccess
{
    public class CostumeDBAccess
    {
        private Database db;

        public CostumeDBAccess(Database db)
        {
            this.db = db;
        }

        public Costume getCostumeByID(int ID)
        {
            Costume found = new Costume();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT * FROM CostumeTBL WHERE CostumeID =" + ID;
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                found = getCostumeFromReader(db.Rdr);
            }
            db.Rdr.Close();
            return found;

        }


        public List<Costume> availableCostumes(DateTime startDate, DateTime ReturnDate)
        {
            List<Costume> availableCostumes = new List<Costume>();
            string startDate1 = startDate.ToString("yyyy-MM-dd HH:mm:ss:ff");
            string returnDate1 = ReturnDate.ToString("yyyy-MM-dd HH:mm:ss:ff");
            db.Cmd.Parameters.Add(new SqlParameter("@startDate1", startDate1));
            db.Cmd.Parameters.Add(new SqlParameter("@returnDate1", returnDate1));
            db.Cmd.CommandText = "SELECT * FROM CostumeTBL WHERE CostumeID NOT IN (SELECT DT.CostumeID FROM RentalTBL DT Where((DT.DateOut <= @startDate1  AND DT.DateIn >= @startDate1) OR (DT.DateOut < @returnDate1 AND DT.Datein >= @returnDate1 ) OR (@startDate1 <= DT.DateOut AND @returnDate1 >= DT.Datein)))";
            //db.Cmd.CommandText = "SELECT * FROM CostumeTBL WHERE CostumeID NOT IN (SELECT RT.CostumeID FROM RentalTBL RT WHERE((RT.DateOut <= @startDate1 AND RT.DateIn >= @startDate1) OR (RT.DateOut < @returnDate1) AND RT.DateIn >= @returnDate1) OR (@startDate1 <= RT.DateOut AND @returnDate1 >= RT.DateIn)))";
            db.Rdr = db.Cmd.ExecuteReader();
            while (db.Rdr.Read())
            {
                availableCostumes.Add(getCostumeFromReader(db.Rdr));
            }
            db.Cmd.Parameters.Clear();
            db.Rdr.Close();
            return availableCostumes;
        }

        public void insertRental(int attenID, int costumeID, DateTime startDate, DateTime returnDate)
        {
            char collected = 'n';
            char returned = 'n';
            string startDate1 = startDate.ToString("yyyy-MM-dd HH:mm:ss:ff");
            string returnDate1 = returnDate.ToString("yyyy-MM-dd HH:mm:ss:ff");
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO RentalTBL(AttendeesID, CostumeID, DateOut, DateIn, Collected, Returned)" + "VALUES(" + attenID + "," + costumeID + ", '" + startDate1 + "','" + returnDate1 + "', '" + collected + "', '" + returned + "')"; 
            db.Cmd.ExecuteNonQuery();
        }

        public Costume getCostumeFromReader(SqlDataReader reader)
        {
            Costume newCostume = new Costume();
            newCostume.CostumeID = reader.GetInt32(0);
            newCostume.Size = reader.GetString(1);
            newCostume.Role = reader.GetString(2);
            newCostume.SupplierID = reader.GetInt32(3);
            return newCostume;
        }
    }
}